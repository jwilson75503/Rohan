#ifndef ROHAN_KERNEL_H
#define ROHAN_KERNEL_H
#include "rohan.h"
#include "crc.h"

__device__ __global__ void mtkContActivate(cuDoubleComplex *Z, int maxN)
;

extern "C" 
void knlContActivate(cuDoubleComplex *Z, const int maxN)
;	

__device__ __global__ void mtkShowMeGPUcdc(int s, int t, char a, char b, char c, char d, cuDoubleComplex * cdc, int maxN)
;

extern "C" 
int knlShowMeGPULS(struct rohanContext& rSes)
;	

extern "C" 
int knlShowMeGPUnnOut(struct rohanContext& rSes)
;

__device__ __global__ void mtkZgemv(int n, int m, cuDoubleComplex *W, cuDoubleComplex *S, cuDoubleComplex *Z)
;

extern "C" 
int knlZgemv(int n, int m, cuDoubleComplex *W, cuDoubleComplex *S, cuDoubleComplex *Z)
;

__device__ __global__ void mtkOutputConvert(cuDoubleComplex *ZOutputs, cuDoubleComplex *gpuYEval, cuDoubleComplex *gpudYEval, cuDoubleComplex *gpuYScalar,  const long lSample, const int N, const int K)
;

extern "C"
int knlOutputConvert(struct rohanContext& rSes)
;

__device__ __global__ void mtkResetDeltasOutputs(cuDoubleComplex *O, cuDoubleComplex *D, cuDoubleComplex *w)
;

extern "C" 
int knlResetDeltasOutputs(struct rohanContext& rSes)
;

__device__ __global__ void mtkTopLayerDeltasCont( cuDoubleComplex *Deltas, cuDoubleComplex *DOutputs, cuDoubleComplex *Yevals, int S)
;

__device__ __global__ void mtkTopLayerDeltasDisc( cuDoubleComplex *Deltas, cuDoubleComplex *DOutputs, cuDoubleComplex *SectBound, cuDoubleComplex *Yeval, int S)
;

extern "C"
int knlTopLayerDeltas(struct rohanContext& rSes, int iCont)
;

__device__ __global__ void mtkHiddenLayerDeltas( cuDoubleComplex *tribDeltas, cuDoubleComplex *layDeltas, cuDoubleComplex *Weights, int N, double recipS)
;

extern "C"
int knlHiddenLayerDeltas(struct rohanContext& rSes)
;

__device__ __global__ void mtkUpdateHidOne( cuDoubleComplex *W, cuDoubleComplex *Deltas, cuDoubleComplex *X, int N, int S)
;

extern "C"
int knlUpdateHidOne(struct rohanContext& rSes)
;

__device__ __global__ void mtkUpdateRemainingW( cuDoubleComplex *W, cuDoubleComplex *Deltas, cuDoubleComplex *X, int N, int S)
;

extern "C"
int knlUpdateRemainingW(struct rohanContext& rSes)
;

extern "C"
double knlEvalSingleSample(struct rohanContext rSes, struct rohanLearningSet * rLearn, struct rohanNetwork * rNet, long lSampleIdxReq)
;

extern "C"
double knlRMSEopt(struct rohanContext& rSes, long lSampleQtyReq, long o, char Option)
;

extern "C"
double knlRMSEnew(struct rdContext * rdSes, struct rdLearningSet * rdLearn, struct rdNetwork * rdNet, long lSampleQtyReq)
;

__global__ __device__ void mtkRMSE(struct rdContext * rdSes, struct rdLearningSet * rdLearn, struct rdNetwork * rdNet, long lSampleQtyReq)
;

__device__ void mtkcEvalSingleSample(struct rdContext * rSes, struct rdLearningSet * rLearn, struct rdNetwork * rNet, long lSampleIdxReq, long threadID)
;

__device__ void mtkcRMSE(cuDoubleComplex *gpuOutScalar, long lSampleQtyReq, int iOutputIdx, int iOutputQty, int k, int kdiv2, double *gpudSE1024, long threadID)
;

__global__ __device__ void mtkRMSEopt( long lSampleQtyReq, long o, char Option)
;

extern "C"
double knlTest()
;

__global__ __device__ void mtkTest() 
;

extern "C"
long knlCRC32Buf(char * buffer, unsigned int length)
;

__global__ __device__ void mtkCRC32Buf(char * buffer, unsigned int length);
;

__device__ long Kcrc32buf(char *buf, size_t len)
;

extern "C" 
long knlA(rohanContext& rSes)
;

__global__ __device__ void mtkA( char arg1, char arg2)
;

extern "C" 
double knlShowMeSes()
;

__global__ __device__ void mtkShowMeSes()
;

extern "C" 
void knlShowMeLearn()
;

__global__ __device__ void mtkShowMeLearn()
;

extern "C" 
void knlXferLearn(rohanContext& rSes)
;

__global__ __device__ void mtkXferLearn()
;

extern "C" 
double knlShowMeNet()
;

__global__ __device__ void mtkShowMeNet()
;

extern "C" 
void knlXferNet(rohanContext& rSes)
;

__global__ __device__ void mtkXferNet()
;

__global__ __device__ void mtkIncrement()
;

extern "C" 
void knlIncrement()
;

extern "C" 
void knlXferSesD(struct rohanContext *rSes)
;

__device__ long subkAddOne(long lDummy)
;

__device__ void subkRMSEopt( const int lSampleQtyReq, const int o, const char Option, const int tid)
;

__device__ void subkEvalSingleSampleUT(long lSampleIdxReq)
;

__device__ void subkConvertInputsUT( long lSample)
;

__device__ void subkEvalMidTopLayersUT( long lSample)
;

__device__ void subkOutputConvertUT(long lSample)
;

__device__ void subkEvalSingleSampleMT(long lSampleIdxReq, long o)
;

__device__ void subkTest2() 
;

__device__ long subkCrc32buf(char *buf, size_t len)
;
__forceinline__ __device__ double FUnitCxUT(const cuDoubleComplex A)
;
__forceinline__ __device__ cuDoubleComplex CxAddCxUT(const cuDoubleComplex A, const cuDoubleComplex B)
;
__forceinline__ __device__ cuDoubleComplex CxMultiplyCxUT(const cuDoubleComplex A, const cuDoubleComplex B)
;
__forceinline__ __device__ cuDoubleComplex CxActivateUT(const cuDoubleComplex Z)
;
__forceinline__ __device__ cuDoubleComplex CxDivideRlUT(const cuDoubleComplex A, const double Rl)
;
__forceinline__ __device__ double CxAbsUT(const cuDoubleComplex Z)
;
#endif
