/* Includes, cuda */

#include <iostream>
using namespace std;
#include "Rohan-data.h"
#include "Rohan-learn.h"
#include "ShowMe.h"
#include <conio.h> //for _getch

extern int iDebugLvl, iWarnings, iErrors, iTrace;
extern long bCUDAavailable;
#define IDX2C( i, j, ld) ((i)+(( j )*( ld )))

int DisplayMenu(int iMenuNum, struct rohanContext& rSes)
{mIDfunc
	char a='.';

	if(iMenuNum==0){
		printf("\n1 - Label session \"%s\"", rSes.sSesName);
		printf("\n2 - Network topology setup");
		printf("\n3 - Sample set load");
		printf("\n4 - Weight set load");
		printf("\n5 - Evaluation Feed Forward");
		printf("\n6 / Learning");
		printf("\n7 - Save weights");
		printf("\n8 - Randomize weights");
		printf("\n9 - showme");
		printf("\n0 - Quit");
		printf("\n %s %d samples MAX %e, %d trainable", rSes.rLearn->sLearnSet, rSes.rLearn->lSampleQty, rSes.dMAX, TrainNNThresh(rSes, false));
		printf("\nDRMSE %e YRMSE %e ", rSes.dTargRMSE, rSes.dRMSE);
		for(int i=0;i<rSes.rNet->iLayerQty;++i)
			printf("L%d %d; ", i, rSes.rNet->rLayer[i].iNeuronQty);
		//if (rLearn.iContOutputs) printf("Output Cont ");
		//else printf("Output Disc ");
		printf("%d sectors ", rSes.rNet->iSectorQty);
		//if (rSes.bContActivation) printf("Activ Cont ");
		//else printf("Activ Disc ");
		if (rSes.bRInJMode) printf("ReverseInput "); 
	}
	printf("\n");
	while(a<'0'||a>'9')
		a=_getch();
	return ((int)a)-48;
}

