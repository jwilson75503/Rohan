int TestPatLS(struct rohanContext& rSes, long bWait)
;

int ShowMeSam(struct rohanContext& rSes, long S, long bWait)
;

int ShowMeLS(struct rohanContext& rSes, int iMode)
;

int ShowMeGPULS(struct rohanContext& rSes, long bWait)
;

int ShowMeES(struct rohanContext& rSes, long bWait)
;

int ShowMeST(struct rohanContext& rSes, long bWait)
;

int TestPatWS(struct rohanContext& rSes, long bWait)
;

int ShowMeArch(struct rohanContext& rSes, long bWait)
;

int ShowMeWS(struct rohanContext& rSes, long bWait)
;

int ShowMeLayer(struct rohanContext& rSes, int L, long bWait)
;

int ShowMeGPUOS(struct rohanContext& rSes, long bWait)
;

int ShowMeErr(struct rohanContext& rSes, long bWait)
;

int ShowMeSes(struct rohanContext& rSes, int iMode)
;

int ShowMeEvals(struct rohanContext& rSes, int iMode)
;
