#include "Rohan.h"
#include "Rohan-data.h"
#include "Rohan-io.h"
#include "Rohan-learn.h"
#include "Rohan-menu.h"
#include "Rohan-kernel.h"
#include "Rohan-class.h"
#include "cTeam.h"
#include "ShowMe.h"
#include "stdafx.h"
#include <conio.h> //for _getch 

#include <cuda.h>

#include <cutil_inline.h>
#include <cuda_runtime_api.h>
#include <multithreading.h>

//#include <time.h> // for tsrtuct
#include <sys/timeb.h>
#include <iostream>
#include <stdlib.h>
using namespace std;
using std::cin;
using std::cout;

#define TWO_PI 6.283185307179586476925286766558
#define IDX2C( i, j, ld) ((i)+(( j )*( ld )))

extern int iDebugLvl, iWarnings, iErrors, iTrace;
extern long bCUDAavailable;

//////////////// class cDrover begins ////////////////

void cDrover::ShowMe()
{
	//ShowMeSes(* rSes, false);
	printf("Am Volga boatman.\n");
}


long cDrover::SetContext( rohanContext& rC)
{/// enables pointer access to master context struct
	rSes = &rC;
	return 0;
}


long cDrover::DoAnteLoop(int argc, char * argv[], class cDrover * cdDrover, class cBarge * cbBarge, class cDeviceTeam * cdtTeam)
{mIDfunc /// This function prepares all parameters, contexts, and data structures necesary for learning and evaluation.
	int iReturn=0;

	// initiate relationship
	SetDroverBargeAndTeam( cdDrover, cbBarge, cdtTeam);
	
	strcpy(rSes->sCLargsOpt, "blank");
	strcpy(rSes->sConfigFileOpt,"blank");
	strcpy(rSes->sConsoleOpt,"blank");
	strcpy(rSes->sLearnSetSpecOpt,"blank");
		
	if (argc) {
		rSes->bConsoleUsed=false;
		rSes->bCLargsUsed=true;
		//strcpy(rSes->sCLargsOpt, argv[0]); // point to first argument
		// call function to parse CLI args here
	}
	else {
		rSes->bConsoleUsed=true;
		rSes->bCLargsUsed=false;
	} /// potentially abusable 
	printf("Rohan v%s Neural Network Application\n", VERSION);
	//print_NVCC_min_spec();
	iTrace=0;
	if (CUDAverify(*rSes)){
		cout << "CUDA present" << endl;
		iReturn=ObtainGlobalSettings(*rSes);
		AskSampleSetName(*rSes);
		if (Barge->ObtainSampleSet(*rSes)){
			//ShowMeEvals(*rSes,1);
			iReturn=Barge->DoPrepareNetwork(*rSes);	
			cdtTeam->LetHitch(*rSes);
			//ShowMeEvals(*rSes,1);
			printf("Team.RMSE = %f\n", cdtTeam->GetRmseNN(*rSes, 0));
			//ShowMeEvals(*rSes,1);
			cdtTeam->TransferOutputs(*rSes,'H');
			//ShowMeEvals(*rSes,1);
			iReturn=ShowDiagnostics(*rSes);
			Barge->ShowDiagnostics();
			cdtTeam->LetUnHitch(*rSes);
		}
		else {
			cout << "Failed to load samples" << endl;
		}
	}
	else {
		fprintf(stderr, "Unrecoverable Error: No CUDA hardware or no CUDA functions present.\n", ++rSes->iErrors);
		iReturn=0;
	}
	//ShowMeEvals(*rSes,1);
	return iReturn;
}


long cDrover::SetDroverBargeAndTeam( class cDrover * cdDrover, class cBarge * cbBarge, class cDeviceTeam * cdtTeam)
{mIDfunc /// sets pointers to hitch barge to team and mount driver on barge
	Barge = cbBarge;
	Team = cdtTeam;
	Barge->SetDrover(cdDrover);
	Barge->SetTeam(Team);
	Team->SetDrover(cdDrover);
	Team->SetBarge(Barge);
	return 0;
}

long cDrover::ObtainGlobalSettings(struct rohanContext& rSes)
{mIDfunc /// sets initial and default value for globals and settings
	int iReturn=0;
	
	//	globals
	iTrace=0; if (iTrace) cout << "Tracing is ON.\n" ;
	iDebugLvl=0; if (iDebugLvl) cout << "Debug level is " << iDebugLvl << "\n";
	// session accrual
	rSes.iWarnings=0; rSes.iErrors=0; cout << "Session warning and session error counts reset.\n";
	rSes.lSampleQtyReq=0;
	// session modes
	rSes.bContActivation=true; cout << "Activation default is CONTINUOUS.\n";
	rSes.bRInJMode=false; if (rSes.bRInJMode) cout << "Reversed Input Order is ON.\n"; // this is working backward for some reason 2/08/11
	rSes.bRMSEon=true; cout << "RMSE stop condition is ON. XX\n"; //
	rSes.iEpochLength=1000; cout << "Epoch length is 1000 iterations.\n";
	strcpy(rSes.sSesName,"DefaultSession");
	rSes.rLearn->bContInputs=true; cout << "Continuous Inputs true by DEFAULT.\n";
	rSes.rLearn->iContOutputs=true; cout << "Continuous Outputs true by DEFAULT.\n";
	
	return iReturn;
}


long cDrover::AskSampleSetName(struct rohanContext& rSes)
{mIDfunc /// chooses the learning set to be worked with Ante-Loop
	int iReturn=0; 
	//rSes.rLearn->bContInputs=false;
	//rSes.rLearn->iContOutputs=(int)false;
	cout << "Samples treated as discrete or continuous by fractionality. XX" << endl;

	printf("Enter 0 for 10K-set, weights\n\t 1 for 3-set, weights\n\t 2 for 150-set, no wgts\n\t 3 for 3-set, no wgts\n\t 4 for 2-1 rand weights");
	printf("\n\t 5 for 416 samples x 200 inputs\nEnter 10+ for basic diag\n\t30+ for more diag\n\t70+ for full diag\n");
	std::cin >> iDebugLvl;
	//cout << "Loading trivial3 test learning set" << endl;
	//iDebugLvl=4;
	switch ( iDebugLvl % 10) {
		case 0:
		  rSes.rLearn->sLearnSet="AirplanePsDN1W3S10k.txt";
		  break;
		case 1:
		  rSes.rLearn->sLearnSet="trivial.txt";
		  break;
		case 2:
		  rSes.rLearn->sLearnSet="iris.txt";
		  break;
		case 3:
		  rSes.rLearn->sLearnSet="trivial2.txt";
		  break;
		case 4:
		  rSes.rLearn->sLearnSet="trivial3.txt";	
		  break;
		case 5:
		  rSes.rLearn->sLearnSet="PC-63-32-200-LearnSet.txt";
		  break;
		default:
		  rSes.rLearn->sLearnSet="iris.txt";
		  break;
	}
	rSes.iDebugLvl=iDebugLvl/=10; // drop final digit
	if (iDebugLvl) fprintf(stderr, "Debug level is %d.\n", iDebugLvl);
	return iReturn;
}


long cDrover::ShowDiagnostics(struct rohanContext& rSes)
{mIDfunc /// show some statistics, dump weights, and display warning and error counts
	double devdRMSE=0.0;
	int iReturn=1;
	long lSamplesEvald;
	
	printf("cDrover: ");
	lSamplesEvald = cuEvalNNLearnSet(rSes);
		if (lSamplesEvald) printf("%d samples evaluated, ", lSamplesEvald);
		else {printf("No samples evaluated by cuEvalNNLearnSet\n");
			++rSes.iErrors;
			printf("Waiting on keystroke...\n"); _getch(); return iReturn;
		}
	////lSamplesEvald=devEvalNNLearnSet(rSes);
	int iDifferent = OutputValidate(rSes);
	printf("%d differences found on verify.\n", iDifferent);
	rSes.dRMSE = RmseNN(rSes, 0);
	////devdRMSE=knlRMSE(rSes, 0);
	printf("RMSE host/dev %e/%e\n", rSes.dRMSE, devdRMSE);
	// some illustrative default values
	rSes.dTargRMSE=floor(rSes.dRMSE-1.0)+1.0;
	rSes.dMAX=(double)abs(rSes.dRMSE-1.0);
	printf("RMSE target is %e.\n", rSes.dTargRMSE);
	printf("MAX threshold is %e.\n", rSes.dMAX);
	int iTrainable = Team->LetTrainNNThresh(rSes, false, 'd');
	printf("%d trainable sample outputs found.\n", iTrainable);

	Barge->LetWriteWeights(rSes);// record weights for posterity
	
	if (rSes.iWarnings) fprintf(stderr, "%d warnings.\n", rSes.iWarnings);
	if (rSes.iErrors) fprintf(stderr, "%d operational errors.\n", rSes.iErrors);

	return iReturn;
}


long cDrover::DoMainLoop(struct rohanContext& rSes)
{mIDfunc /// Trains a weight set to more closely reproduce the sampled outputs from the sampled inputs, and other options.
	int iReturn=0, iSelect=1;
	cout << "Main duty loop begin." << endl;
	
	while(iSelect){
		iSelect=DisplayMenu(0, rSes);
		if (iSelect==1) iReturn=BeginSession(rSes); // new or resume session
		if (iSelect==2) iReturn=GetNNTop(rSes);
		//if (iSelect==3) iReturn=ReGetSampleSet(rSes); XX
		if (iSelect==4) iReturn=GetWeightSet(rSes);
		if (iSelect==5) iReturn=this->LetInteractiveEvaluation(rSes);
		if (iSelect==6) iReturn=this->LetInteractiveLearning(rSes);
		if (iSelect==7) iReturn=cuPreSaveNNWeights(rSes);
		if (iSelect==8) iReturn=dualRandomizeWeights(rSes);
		//if (iSelect==8) iReturn=TestPatLS(rSes, false)+ShowMeLS(rSes, false)+ShowMeST(rSes, false)+TestPatWS(rSes, false)+ShowMeWS(rSes, false)+ShowMeSes(rSes, false);
		//if (iSelect==9) iReturn=devResetAllDeltasAndOutputs(rSes)+ShowMeErr(rSes, false)+ShowMeLS(rSes, true)+ShowMeWS(rSes, false)+ShowMeSes(rSes, false);
		//if (iSelect==9) iReturn=devResetAllDeltasAndOutputs(rSes)+ShowMeErr(rSes, false)+ShowMeLS(rSes, false)+ShowMeWS(rSes, false)+ShowMeSes(rSes, false);
		if (iSelect==9) {
			//ShowMeLS(rSes,1);
			ShowMeSes(rSes,1);
			ShowMeEvals(rSes,1);
		}
		SilentDiagnostics(rSes);
	}
	return 0;
}


int BeginSession(struct rohanContext& rSes)
{mIDfunc /// accepts keyboard input to define the name of the session, which will be used to name certain output files.
	cout << "\nEnter a session name: ";
	cin >> rSes.sSesName; 

	return 1;
}


int GetNNTop(struct rohanContext& rSes)
{mIDfunc /// sets up network poperties and data structures for use
	char sNeuronsPerLayer[254];
	int iSectorQty, iInputQty;

	cout << "Enter # of sectors (0 to return): ";
	cin >> iSectorQty;
	if(iSectorQty){
		cout << "Enter # of inputs (0 to return): ";
		cin >> iInputQty; // last chance to quit
	}
	if(iSectorQty && iInputQty) {
		cuFreeNNTop(rSes); // release old network structures
		rSes.rNet->iSectorQty=iSectorQty; // update sector qty
		rSes.rNet->kdiv2=iSectorQty/2; // update sector qty
		rSes.rLearn->iInputQty=iInputQty; // upsdate input qty
		cout << "Enter numbers of neurons per layer separated by commas, \ne.g. 63,18,1 : ";
		cin >> sNeuronsPerLayer;
		cuMakeLayers(iInputQty, sNeuronsPerLayer, rSes); // make new layers
		rSes.rNet->dK_DIV_TWO_PI = rSes.rNet->iSectorQty / TWO_PI; // Prevents redundant conversion operations
		cuMakeNNStructures(rSes); // allocates memory and populates network structural arrays
		cuRandomizeWeights(rSes); // populate newtork with random weight values
		printf("Random weights loaded.\n");
		printf("%d-valued logic sector table made.\n", cuSectorTableMake(rSes));
		printf("\n");
		return rSes.rNet->iLayerQty;
	}
	else
		return 999;
}


long cuFreeNNTop(struct rohanContext &rSes)
{mIDfunc/// frees data structures related to network topology
	cublasStatus csStatus;
	
	free( rSes.rNet->cdcSectorBdry );
	// layer components
	free( rSes.rNet->rLayer[0].ZOutputs ); // Layer Zero has no need of weights!
	csStatus = cublasFree( rSes.rNet->rLayer[0].ZOutputs ); // de-allocate a GPU-space pointer to a vector of complex neuron outputs for each layer
	mCuMsg(csStatus,"cublasFree()")
	
	for (int i=1; i < rSes.rNet->iLayerQty; ++i){ 
		struct rohanLayer& lay=rSes.rNet->rLayer[i];
		free( lay.Weights ); // de-allocate a pointer to an array of arrays of weights
		free( lay.ZOutputs ); // de-allocate a pointer to an array of arrays of weights
		free( lay.Deltas ); // free the backprop areas
	}
	free( rSes.rNet->rLayer ); // free empty layers
	printf("Network structures freed.\n");
	return 0;
}


int GetWeightSet(struct rohanContext& rSes)
{mIDfunc /// chooses and loads the weight set to be worked with
	int iReturn=0; 
	char sWeightSet[254];
	FILE *fileInput;
	
	cout << "Enter name of binary weight set: ";
	std::cin >> sWeightSet;
	// File handle for input
	
	iReturn=BinaryFileHandleRead(sWeightSet, &fileInput);
	if (iReturn==0) // unable to open file
		++rSes.iErrors;
	else{ // file opened normally
		// file opening and reading are separated to allow for streams to be added later
		iReturn=cuNNLoadWeights(rSes, fileInput);
		if (iReturn) printf("%d weights read.\n", 
			iReturn);
		else {
			printf("No Weights Read\n");
			iReturn=0;
		}
	}
	printf("\n");
	return iReturn;
}


long cDrover::LetInteractiveEvaluation(struct rohanContext& rSes)
{mIDfunc /// allows user to ask for different number of samples to be evaluated
	int iReturn=0;
	printf("Enter qty of samples to evaluate, or 0 to end\n");
	std::cin >> rSes.lSampleQtyReq;
	++iReturn;
	while(rSes.lSampleQtyReq){
		// serial values are computed and then displayed
		//cuEvalNNLearnSet(rSes);
		Team->LetEvalSet(rSes,0,'c');
		rSes.dRMSE = RmseNN(rSes, rSes.lSampleQtyReq);
		printf("%s: first %d samples requested\nRMSE= %f", rSes.rNet->sWeightSet, rSes.lSampleQtyReq, rSes.dRMSE);
		// parallel method takes over in mid-sentence to visualize speed difference
		////devEvalNNLearnSet(rSes);
		double devdRMSE=knlRMSEopt(rSes, rSes.lSampleQtyReq, 0, 'R'); // XX
		printf("/%f\n", devdRMSE);
		printf("Enter qty of samples to evaluate, or 0 to end\n");
		std::cin >> rSes.lSampleQtyReq;
		++iReturn;
	}
	return iReturn;
}


long cDrover::LetInteractiveLearning(struct rohanContext& rSes)
{mIDfunc /// allows user to select learning threshold
	int iReturn=0;
	//rSes.dRMSE = RmseNN(rSes, 0);
	rSes.dRMSE = knlRMSEopt(rSes,0,0,'R');
	//double dTargRMSE;
	printf(" Achieved RMSE = % #3.3g\n", rSes.dRMSE);
	printf("Enter desired RMSE for learning, or 0 to end\n");
	std::cin >> rSes.dTargRMSE;
	if(rSes.dTargRMSE){
		printf(" MAX = % #3.3g\n", rSes.dRMSE);
		printf("Enter MAX allowable error per sample, or 0 to end\n");
		std::cin >> rSes.dMAX;
		if(rSes.dMAX){
			printf(" Epoch length = %d\n", rSes.iEpochLength);
			printf("Enter iterations per epoch, or 0 to end\n");
			std::cin >> rSes.iEpochLength;
			if(rSes.iEpochLength){
				printf(" Sample qty = %d\n", rSes.lSampleQtyReq);
				printf("Enter samples requested, or 0 to end\n");
				std::cin >> rSes.lSampleQtyReq;
				if(rSes.lSampleQtyReq){
					++iReturn;
					long count = 0; rSes.lSamplesTrainable=1; //set trainable to 1 to allow loop to proceed at least once
					while(rSes.dTargRMSE<rSes.dRMSE && rSes.lSamplesTrainable && count < rSes.iEpochLength){ // target not met, trainable samples left
						rSes.lSamplesTrainable=TrainNNThresh(rSes , true);
						cuEvalNNLearnSet(rSes);
						////devEvalNNLearnSet(rSes);
						//rSes.dRMSE = RmseNN(rSes, 0);
						rSes.dRMSE = knlRMSEopt(rSes, rSes.lSampleQtyReq, 0,'R' );
						//printf(" RMSE = %f/%f, trainables %d, iteration %d\n", RmseNN(rSes, 0), rSes.dRMSE, rSes.lSamplesTrainable,++count);
						//++count;
						printf(" RMSE = % #3.5g, trainable samples %d, iteration %d\n", rSes.dRMSE, rSes.lSamplesTrainable, ++count);
						++iReturn;
					}
				}
			}
			if(rSes.lSamplesTrainable)
				if(rSes.dTargRMSE>=rSes.dRMSE)
					printf(" Achieved RMSE target %f.\n", rSes.dRMSE);
				else printf(" Completed epoch of %d iterations.\n", rSes.iEpochLength);
			else printf(" No trainable samples with MAX % #3.3g\n", rSes.dMAX);
		}
	}
	return iReturn;
}


long cDrover::DoPostLoop(struct rohanContext& rSes) 
{mIDfunc /// Final operations including freeing of dynamically allocated memory are called from here. 
	int iReturn=0, iSelect=0;

	printf("Program terminated after %d warning(s), %d operational error(s).\n", rSes.iWarnings, rSes.iErrors);
	DoEndItAll(rSes);
	printf("Waiting on keystroke...\n");
	_getch();

	return 0;
}


int SilentDiagnostics(struct rohanContext& rSes)
{mIDfunc /// show some statistics, dump weights, and display warning and error counts
	int iReturn=0;
	
	long lSamplesEvald = cuEvalNNLearnSet(rSes);
	int iDifferent = OutputValidate(rSes);
	//printf("%d differences found on verify.\n", iDifferent);
	rSes.dRMSE = RmseNN(rSes, 0);
	//printf("RMSE %f\n", rSes.dRMSE);
	// some illustrative default values
	rSes.dTargRMSE=floor(rSes.dRMSE-1.0)+1.0;
	rSes.dMAX=(double)abs(rSes.dRMSE-1.0);
	//printf("RMSE target is %f.\n", rSes.dTargRMSE);
	//printf("MAX threshold is %f.\n", rSes.dMAX);
	int iTrainable = TrainNNThresh(rSes, false);
	//printf("%d trainable sample outputs found.\n", iTrainable);

	// dump weights for verification
	FILE *fileOutput; // File handle for input
	iReturn=AsciiFileHandleWrite("weightdump.txt", &fileOutput);
	AsciiWeightDump(rSes, fileOutput); //XX link error
	
	if (rSes.iWarnings) fprintf(stderr, "%d warnings.\n", rSes.iWarnings);
	if (rSes.iErrors) fprintf(stderr, "%d operational errors.\n", rSes.iErrors);

	return iReturn;
}


long cDrover::DoEndItAll(struct rohanContext& rSes)
{mIDfunc /// prepares for graceful ending of program
	int iReturn=0;

	iReturn=Barge->DoCuFree(rSes);

	return iReturn;
}
