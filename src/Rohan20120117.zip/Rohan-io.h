/* Includes, cuda */



int CUDAverify(struct rohanContext& rSes)
;
int BinaryFileHandleRead(char* sFileName, FILE** fileInput)
;
int AsciiFileHandleRead(char *sFileName, FILE **fileInput)
;
long AsciiFileHandleWrite(char *sFileName, FILE **fileOutput)
;
long AsciiWeightDump(struct rohanContext& rSes, FILE *fileOutput)
;


long LoadNNWeights(int iLayerQty, int iNeuronQty[], double ****dWeightsR, double ****dWeightsI, FILE *fileInput)
;
//long WriteWeights(struct rohanContext& rSes)
//;

int cuMessage(cublasStatus csStatus, char *sName, char *sCodeFile, int iLine, char *sFunc)
;
int cuMakeLayers(int iInputQty, char *sLayerSizes, struct rohanContext& rSes)
;
int cuMakeArchValues(char *sMLMVNarch, struct rohanContext& rSes)
;
long cuLoadSampleSet(struct rohanContext& rSes, FILE *fileInput)
;
long cuReLoadSampleSet(struct rohanContext& rSes, FILE *fileInput)
;
long cuNNLoadWeights(struct rohanContext& rSes, FILE *fileInput)
;
long cuPreSaveNNWeights(struct rohanContext& rSes)
;
long cuSaveNNWeights(struct rohanContext& rSes, FILE *fileOutput)
;
long cuSaveNNWeightsASCII(struct rohanContext& rSes, FILE *fileOutput)
;

//int cuPrepareNetwork(struct rohanContext& rSes)
//;


int devCopyArchValues(struct rohanContext& rSes)
;
long devCopySampleSet(struct rohanContext& rSes)
;
long devCopyNNWeights(struct rohanContext& rSes)
;
int devPrepareNetwork(struct rohanContext& rSes)
;
