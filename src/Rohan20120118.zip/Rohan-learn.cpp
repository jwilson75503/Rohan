/* Includes, cuda */

#include <cutil_inline.h>
#include <cuda_runtime_api.h>
#include "Rohan.h"
#include "Rohan-io.h"
#include "Rohan-data.h"
#include "Rohan-kernel.h"
#include "Rohan-class.h"
//#include "cuPrintf1.cuh"
#include "Complex-math-func.h"
#include "ShowMe.h"
#define _USE_MATH_DEFINES
#include <math.h>  //for M_PI
#define ONE_PI 3.14159265358979323846264338327950288
#define TWO_PI 6.283185307179586476925286766558
#define TWO_PI_OVER_384 0.01636246173744683978365960095458

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//#define IDX2C( i, j, ld) ((i)+(( j )*( ld )))
#define IDX2C( i, j, ld) ((i)+(( j )*( ld )))

extern int iDebugLvl, iTrace;

//int devEvalSingleSample(struct rohanContext& rSes, long lSampleIdxReq)
//{mIDfunc
//	/*! here beginneth evaluation of sam. */
//	if (rSes.lSampleQtyReq<=0 || rSes.lSampleQtyReq>rSes.rLearn->lSampleQty)
//		rSes.lSampleQtyReq=rSes.rLearn->lSampleQty;
//	
//	/*! layer zero (inputs) is special. */
//	int N=rSes.rNet->rLayer[1].iNeuronQty+1;
//	int D=rSes.rNet->rLayer[1].iDendriteQty+1;
//	/*! MULTIPLY: sample inputs x first layer weights = first layer weighted sums */
//	knlZgemv(N, D, rSes.rNet->rLayer[1].Weights, rSes.rLearn->rSample[lSampleIdxReq].gpuXInputs, rSes.rNet->rLayer[1].ZOutputs);
//	/*! ACTIVATE: normalize sums to signals */
//	knlContActivate(rSes.rNet->rLayer[1].ZOutputs, N);	
//
//	if (rSes.rNet->iLayerQty>1){
//		for(int i=2;i<rSes.rNet->iLayerQty; ++i){ // corrected this from <= to < 7/11/11
//			int N=rSes.rNet->rLayer[i].iNeuronQty+1;
//			int D=rSes.rNet->rLayer[i].iDendriteQty+1;
//			/*! MULTIPLY. */
//			knlZgemv(N, D, rSes.rNet->rLayer[i].Weights, rSes.rNet->rLayer[i-1].ZOutputs, rSes.rNet->rLayer[i].ZOutputs);
//			/*! ACTIVATE. */
//			knlContActivate(rSes.rNet->rLayer[i].ZOutputs, N);	
//		}
//	}
//	devOutputConvert(rSes, lSampleIdxReq);
//	 /*! end of sample evaluation. */
//	//knlEvalSingleSample(rSes, rSes.rLearn, rSes.rNet, lSampleIdxReq);
//	return 0;
//}

int cuEvalSingleSample(struct rohanContext& rSes, long lSample)
{mIDfunc
	int iMethodsUsed=0;
	 /*! here beginneth evaluation of sam. */
	 /*! layer zero (inputs) is special. */
		cuConvertInputs(rSes, lSample);
	 /*! middle and top layers. */
		cuEvalMidTopLayers(rSes, lSample);
	 /*! last layer is also special  IMPORTANT keep synchronized with cuEvalSingleOutput in rohan-learn.cpp. */
		cuOutputConvert(rSes, lSample);
	 /*! end of sample evaluation. */
		++iMethodsUsed;

	return iMethodsUsed;
}

int cuEvalSingleOutput(rohanContext& rSes, long lSampleIdxReq, int iOutputIdxReq)
{mIDfunc/*! This will apply an MLMVN weight set to a _given_ sample of a learning set and record the resulting final output for each.
 /*! ! Discrete inputs and outputs are used. Real integers are converted via K-valued logic to complex coordinates,
 /*! ! which are then product-summed by successive layers of neurons, then conveted back to integer output
 /*! !
 /*! ! IMPORTANT: keep this code consistent with cuEvalNNLearnSet in rohan-data.cpp. */
	long ROWLEN = rSes.rLearn->iOutputQty+1;

	long s=lSampleIdxReq /*! replace for-loop domain with requested sample index. */;
	double two_pi_div_sect_qty = TWO_PI/rSes.rNet->iSectorQty;
	//struct rohanSample& sam = rSes.rLearn->rSample[s];
 	cuEvalSingleSample(rSes, s);
	int i=iOutputIdxReq; // replace for-loop domain with requested output index
	return (int)rSes.rLearn->dYEval[ IDX2C( i, s, ROWLEN ) ]; /*! return evaluated result. */
}	

long OutputValidate(rohanContext& rSes)
{mIDfunc  /*! compares outputs by sample and by method to verify bulk outputs.. */
	int iReturn=0;
	long ROWLEN = rSes.rLearn->iOutputQty+1;
	
	for(long s=0; s<rSes.rLearn->lSampleQty; ++s){
		for(int i=0; i<=rSes.rLearn->iOutputQty; ++i){
			//printf("%d %d %f %f\t", s, i, rSes.rLearn->dYEval[ IDX2C( s, i, ROWLEN ) ] , rSes.rLearn->dAltYEval[ IDX2C( s, i, ROWLEN ) ] );
			if(rSes.rLearn->iContOutputs){
				if( abs(rSes.rLearn->dYEval[ IDX2C( i, s, ROWLEN ) ] - rSes.rLearn->dAltYEval[ IDX2C( i, s, ROWLEN ) ] ) >0.5 )
					++iReturn;
			}
			else{
				if( rSes.rLearn->dYEval[ IDX2C( i, s, ROWLEN ) ] - rSes.rLearn->dAltYEval[ IDX2C( i, s, ROWLEN ) ] )
					++iReturn;
			}
		}
	}
	return iReturn; // return number of outputs that diverged
}


int devResetAllDeltasAndOutputs(rohanContext& rSes)
{mIDfunc
	//knlResetDeltasOutputs(rSes);
	return 0;
}

int cuResetAllDeltasAndOutputs(rohanContext& rSes)
{mIDfunc
	for (int L=1; L<rSes.rNet->iLayerQty; ++L)  /*! reset outputs and deltas for full neuron layers. */
		for (int i = 0; i<=rSes.rNet->rLayer[L].iNeuronQty; ++i){
			rSes.rNet->rLayer[L].Deltas[i]=cdcZero;
			rSes.rNet->rLayer[L].ZOutputs[i]=cdcZero;
		}
	
	return 0;
}


//int devBackpropSingleSample(rohanContext& rSes, long lSampleIdxReq)
//{ mIDfunc /*! propagates adjustment of weights backwards preceeding layers from the chosen network output. */
//	int iReturn=0 /* returns number of weights adjusted */ ;
//	rSes.rLearn->iContOutputs=(int)true;
//	/* clear all temp values*/
//	devResetAllDeltasAndOutputs(rSes); 
//	 /* re-evaluate sample to load temp values. */
//	devEvalSingleSample(rSes, lSampleIdxReq); 
//	 /* begin error calculation. */
//	 /* calc top layer deltas. */
//	knlTopLayerDeltas(rSes, rSes.rLearn->iContOutputs); 
//	 /* Now distribute the correction to lower layers if any. */
//	if (rSes.rNet->iLayerQty>2){  /* remember layer 0 = inputs, layer 1 = bottom row, layer {2..iLayerQty-2} = middle row, layer iLayerQty-1 = top row. */
//		knlHiddenLayerDeltas(rSes);
//		 /* and now update the weights 
//		 /* adj weights on first hidden layer. */
//		knlUpdateHidOne(rSes);
//		 /* re-evaluate sample to update temp values. */
//		devEvalSingleSample(rSes, lSampleIdxReq);
//		 /* now use those outputs' conjugates and the deltas to adjust. */
//		knlUpdateRemainingW(rSes);
//		/* backprop is complete. */
//	}
//	else{
//		 /* and now update the weights 
//		 /* adj weights on first hidden layer. */
//		knlUpdateHidOne(rSes);
//		 /* re-evaluate sample to update temp values. */
//		devEvalSingleSample(rSes, lSampleIdxReq);
//		/* backprop is complete. */
//	}
//	return iReturn; /* number of weights updated. */
//}


//int dualBackpropSingleSample(rohanContext& rSes, long lSampleIdxReq)
//{ mIDfunc /*! propagates adjustment of weights backwards preceeding layers from the chosen network output. */
//	int iReturn=0 /* returns number of weights adjusted */ ;
//	rSes.rLearn->iContOutputs=(int)true;
//	//printf("Begin sample %d\n", lSampleIdxReq);
//	 /* clear all temp values*/
//	cuResetAllDeltasAndOutputs(rSes);
//	////devResetAllDeltasAndOutputs(rSes); //ShowMeLayer(rSes, 1, false)+ShowMeLayer(rSes, 2, true);
//		 /* printf("\nEvaluating sample %d from %s...\n", lSampleIdxReq, rSes.rLearn->sLearnSet); 
//	 /* re-evaluate sample to load temp values. */
//	cuEvalSingleSample(rSes, lSampleIdxReq);
//	////devEvalSingleSample(rSes, lSampleIdxReq); //ShowMeLayer(rSes, 2, false)+ShowMeSam(rSes, lSampleIdxReq, true);
//	 /* begin error calculation. */
//	cuDoubleComplex Deltastar /* measured error at the chosen network output. */ ;
//		struct rohanSample& sam = rSes.rLearn->rSample[lSampleIdxReq];
//		struct rohanLayer& top = rSes.rNet->rLayer[rSes.rNet->iLayerQty-1];
//	 /* calc top layer deltas. */
//
//	for(int i=0; i<=top.iNeuronQty; ++i){
//		 /* delta-star = D - Y = Desired output minus actual output from evaluation
//		 /* D is the cplx coords of the sector of the desired answer		Y is the complex result of evaluation of the given sample. */
//		if(rSes.rLearn->iContOutputs)
//			Deltastar = CxSubtractCx( sam.cdcDOutputs[i], sam.cdcYEval[i]);
//		else
//			Deltastar = CxSubtractCx( sam.cdcDOutputs[i], rSes.rNet->cdcSectorBdry[(int) sam.dYEval[i ]] );
//		 /* divide the correction; delta = alpha * delta-star / n+1 (but alpha is always 1 for now). */
//		top.Deltas[i] = CxDivideRl( Deltastar, top.iDendriteQty+1 ); /* 11/11/10 - found this had been multiplying instead of dividing. */ 
//	}
//	knlTopLayerDeltas(rSes, rSes.rLearn->iContOutputs); 
//	 /* Now distribute the correction to lower layers if any. *///ShowMeLayer(rSes, 2, false);ShowMeLayer(rSes, 1, false); ShowMeSam(rSes, lSampleIdxReq, true);
//	if (rSes.rNet->iLayerQty>2){  /* remember layer 0 = inputs, layer 1 = bottom row, layer {2..iLayerQty-2} = middle row, layer iLayerQty-1 = top row. */
//		for (int L=rSes.rNet->iLayerQty-1; L>1; --L){
//			 /* setup access to layers. */
//			struct rohanLayer& lay = rSes.rNet->rLayer[L];
//			struct rohanLayer& trib = rSes.rNet->rLayer[L-1] /* trib for tributary.*/ ;
////			printf("serial %d %d\n", trib.iNeuronQty, lay.iDendriteQty);
//			for (int i=1; i<=lay.iNeuronQty; ++i) { //neuron zero's delta doesn't propagate? 6/11//11
//				for (int j=0; j<=trib.iNeuronQty; ++j) { /* the contribution to ith neuron's jth tributary's delta = i's delta/i's weight j. */
//					trib.Deltas[j] = CxAddCx( trib.Deltas[j] , CxDivideCx( lay.Deltas[i] , lay.Weights[IDX2C(i,j,lay.iNeuronQty+1)] ));
////					if(j==1) printf("serial %d,%d %f = %f / %f \n", i, j, trib.Deltas[j].x, lay.Deltas[i].x, lay.Weights[IDX2C(i,j,lay.iNeuronQty+1)].x);
////					printf("<%d,%d>\t", i, j);
//				}
//			}
//			for (int j=0; j<=trib.iNeuronQty; ++j) { /* contributions accumulated, now divide by dendrites+1. */
//				trib.Deltas[j] = CxDivideRl( trib.Deltas[j] , trib.iDendriteQty+1 );
//				//printf("%f %f / %d\n",  trib.Deltas[j].x, trib.Deltas[j].y , trib.iDendriteQty+1);
//			}
//		}
//		knlHiddenLayerDeltas(rSes);
//	}
//		//ShowMeLayer(rSes, 1, false);
//	//ShowMeLayer(rSes, 2, true); ShowMeWS(rSes, false);
//	//ShowMeSam(rSes, lSampleIdxReq, true);
//	 /* and now update the weights 
//	
//	 /* adj weights on first hidden layer. */
//		struct rohanLayer& hid = rSes.rNet->rLayer[1];
//		struct rohanLayer& trib = rSes.rNet->rLayer[0] /* trib for tributary. */ ;
//	for (int k=1; k<=hid.iNeuronQty; ++k){
//		for (int i=0; i<=rSes.rLearn->iInputQty; ++i){  /* dW=d*xbar/s1/|z|= neuron's sigma * input's conjugate / (abs of previous prod-sum * ddendrites+1). */
//			hid.Weights[IDX2C(k,i,hid.iNeuronQty+1)]=CxAddCx(hid.Weights[IDX2C(k,i,hid.iNeuronQty+1)], CxDivideRl(CxMultiplyCx(hid.Deltas[k], CxConjugate(trib.ZOutputs[i])), CxAbs(hid.ZOutputs[k])));
//		}
//	}
//	knlUpdateHidOne(rSes);
//	//ShowMeLayer(rSes, -1, false);ShowMeLayer(rSes, -2, true);
//	 /* re-evaluate sample to update temp values. */
//	cuEvalSingleSample(rSes, lSampleIdxReq);
//	devEvalSingleSample(rSes, lSampleIdxReq);
//	//ShowMeLayer(rSes, -2, false);ShowMeLayer(rSes, -1, false); ShowMeWS(rSes, false);ShowMeSam(rSes, lSampleIdxReq, true);
//	if (rSes.rNet->iLayerQty>2){
//		 /* now use those outputs' conjugates and the deltas to adjust. */
//		for (int L=2; L<=rSes.rNet->iLayerQty-1; ++L){
//			 /* setup access to layers. */
//			struct rohanLayer& lay = rSes.rNet->rLayer[L];
//			struct rohanLayer& trib = rSes.rNet->rLayer[L-1] /* trib for tributary. */ ;
//			//for (int i=1; i<=lay.iNeuronQty; ++i){
//			//	for (int j=0; j<=trib.iNeuronQty; ++j){  /* the adjustment added to ith neruon's jth trib's weight = ( alpha-always-1 / (weights + 1) ) * j's delta * complex conjugate of j's input. */
//			//		//lay.cdcAltWeights[IDX2C(i,j,lay.iNeuronQty+1)] = CxAddCx( lay.Weights[IDX2C(i,j,lay.iNeuronQty+1)] , CxMultiplyCx( CxDivideRl( lay.Deltas[i] , (lay.iDendriteQty+1)) ,  CxConjugate(trib.ZOutputs[j])) ); 
//			//	}
//			//}
//			/* now put the updated weights in place and use them to generate revised outputs for the next layer's benefit. */
//			for (int i=1; i<=lay.iNeuronQty; ++i){
//				for (int j=0; j<=trib.iNeuronQty; ++j){
//					//lay.Weights[i][j]=lay.cdcAltWeights[i][j]; ++iReturn;
//					//int N=lay.iNeuronQty+1;printf("%f +=%f *%f -%f *%f %d/%d/%d\n", lay.ZOutputs[i].x ,  lay.Weights[IDX2C(i,j,N)].x, trib.ZOutputs[j].x ,  lay.Weights[IDX2C(i,j,N)].y, trib.ZOutputs[j].y, i, j, N);
//					lay.ZOutputs[i] = CxAddCx( lay.ZOutputs[i], CxMultiplyCx(lay.Weights[IDX2C(i,j,lay.iNeuronQty+1)] , trib.ZOutputs[j]) );
//					//printf("%f +=%f *%f -%f *%f %d/%d/%d\n", lay.ZOutputs[i].x ,  lay.Weights[IDX2C(i,j,N)].x, trib.ZOutputs[j].x ,  lay.Weights[IDX2C(i,j,N)].y, trib.ZOutputs[j].y, i, j, N);
//				}
//			}
//			/* layer is complete. */
//		}
//		knlUpdateRemainingW(rSes);
//		//ShowMeLayer(rSes, -1, false);ShowMeLayer(rSes, -2, false);
//		/* backprop is complete. */
//	}
//	 /* for(int i=1; i<=rSes.rLearn->iOutputQty; ++i){  /* loop over outputs
//	 /* 	double dDelta = (double) abs( sam.dXInputs[rSes.rLearn->iInputQty+i] - sam.dYEval[i] );
//	 /* 	printf("%f ", dDelta);
//	 /* }
//	 /* printf("\n");. */
//	//for(int i=1; i<=top.iNeuronQty; ++i){
//		 /* delta-star = D - Y = Desired output minus actual output from evaluation
//		 /* D is the cplx coords of the sector of the desired answer		Y is the complex result of evaluation of the given sample. */
//	//	Deltastar = CxSubtractCx( rSes.rNet->cdcSectorBdry[(int) sam.dXInputs[ rSes.rLearn->iInputQty+i ]] , top.ZOutputs[i] );
//		 /* printf("after : % 1f+% 1fi = % 1f+% 1fi - % 1f+% 1fi\n", Deltastar.x, Deltastar.y, 
//			 /* rSes.rNet->cdcSectorBdry[(int) sam.dXInputs[ rSes.rLearn->iInputQty+i ]].x, rSes.rNet->cdcSectorBdry[(int) sam.dXInputs[ rSes.rLearn->iInputQty+i ]].y,
//			 /* top.ZOutputs[i].x, top.ZOutputs[i].y);. */
//	//}
//	return iReturn; /* number of weights updated. */
//}


int cuBackpropSingleSample(rohanContext& rSes, long lSampleIdxReq)
{ mIDfunc /*! propagates adjustment of weights backwards preceeding layers from the chosen network output. */
	int iReturn=0 /* returns number of weights adjusted */ ;
	long ROWLEN = rSes.rLearn->iOutputQty+1;
	 /* clear all temp values*/
	cuResetAllDeltasAndOutputs(rSes);
		 /* printf("\nEvaluating sample %d from %s...\n", lSampleIdxReq, rSes.rLearn->sLearnSet); 
	 /* re-evaluate sample to load temp values. */
	cuEvalSingleSample(rSes, lSampleIdxReq);
	 /* begin error calculation. */
	cuDoubleComplex Deltastar /* measured error at the chosen network output. */ ;
		//struct rohanSample& sam = rSes.rLearn->rSample[lSampleIdxReq];
		struct rohanLayer& top = rSes.rNet->rLayer[rSes.rNet->iLayerQty-1];
	 /* calc top layer deltas. */
	for(int i=0; i<=top.iNeuronQty; ++i){
		 /* delta-star = D - Y = Desired output minus actual output from evaluation
		 /* D is the cplx coords of the sector of the desired answer		Y is the complex result of evaluation of the given sample. */
	Deltastar = CxSubtractCx( rSes.rLearn->cdcDOutputs[ IDX2C( i, lSampleIdxReq, ROWLEN ) ], 
		rSes.rNet->cdcSectorBdry[(int) rSes.rLearn->dYEval[ IDX2C( i, lSampleIdxReq, ROWLEN ) ] ] );
		 /* divide the correction; delta = alpha * delta-star / n+1 (but alpha is always 1 for now). */
		top.Deltas[i] = CxDivideRl( Deltastar, top.iDendriteQty+1 ); /* 11/11/10 - found this had been multiplying instead of dividing. */ 
	}
	 /* Now distribute the correction to lower layers if any. */ 
	if (rSes.rNet->iLayerQty>2){  /* remember layer 0 = inputs, layer 1 = bottom row, layer {2..iLayerQty-2} = middle row, layer iLayerQty-1 = top row. */
		for (int L=rSes.rNet->iLayerQty-1; L>1; --L){
			 /* setup access to layers. */
			struct rohanLayer& lay = rSes.rNet->rLayer[L];
			struct rohanLayer& trib = rSes.rNet->rLayer[L-1] /* trib for tributary.*/ ;
			for (int i=1; i<=lay.iNeuronQty; ++i) {
				for (int j=0; j<=trib.iNeuronQty; ++j) { /* the contribution to ith neuron's jth tributary's delta = i's delta/i's weight j. */
					trib.Deltas[j] = CxAddCx( trib.Deltas[j] , CxDivideCx( lay.Deltas[i] , lay.Weights[IDX2C(i,j,lay.iNeuronQty+1)] ));
				}
			}
			for (int j=0; j<=trib.iNeuronQty; ++j) { /* contributions accumulated, now divide by dendrites+1. */
				trib.Deltas[j] = CxDivideRl( trib.Deltas[j] , trib.iDendriteQty+1 );
			}
		}
	}
	 /* and now update the weights 
	
	 /* adj weights on first hidden layer. */
		struct rohanLayer& hid = rSes.rNet->rLayer[1];
		struct rohanLayer& trib = rSes.rNet->rLayer[0] /* trib for tributary. */ ;
	for (int k=1; k<=hid.iNeuronQty; ++k){
		for (int i=0; i<=rSes.rLearn->iInputQty; ++i){  /* dW=d*xbar/s1/|z|= neuron's sigma * input's conjugate / (abs of previous prod-sum * ddendrites+1). */
			hid.Weights[IDX2C(k,i,hid.iNeuronQty+1)]=CxAddCx(hid.Weights[IDX2C(k,i,hid.iNeuronQty+1)], CxDivideRl(CxMultiplyCx(hid.Deltas[k], CxConjugate(trib.ZOutputs[i])), CxAbs(hid.ZOutputs[k])));
		}
	}
	 /* re-evaluate sample to update temp values. */
	cuEvalSingleSample(rSes, lSampleIdxReq);
	if (rSes.rNet->iLayerQty>2){
		 /* now use those outputs' conjugates and the deltas to adjust. */
		for (int L=2; L<=rSes.rNet->iLayerQty-1; ++L){
			 /* setup access to layers. */
			struct rohanLayer& lay = rSes.rNet->rLayer[L];
			struct rohanLayer& trib = rSes.rNet->rLayer[L-1] /* trib for tributary. */ ;
			for (int i=1; i<=lay.iNeuronQty; ++i){
				for (int j=0; j<=trib.iNeuronQty; ++j){  /* the adjustment added to ith neruon's jth trib's weight = ( alpha-always-1 / (weights + 1) ) * j's delta * complex conjugate of j's input. */
					//lay.cdcAltWeights[IDX2C(i,j,lay.iNeuronQty+1)] = CxAddCx( lay.Weights[IDX2C(i,j,lay.iNeuronQty+1)] , CxMultiplyCx( CxDivideRl( lay.Deltas[i] , (lay.iDendriteQty+1)) ,  CxConjugate(trib.ZOutputs[j])) ); 
				}
			}
			/* now put the updated weights in place and use them to generate revised outputs for the next layer's benefit. */
			for (int i=1; i<=lay.iNeuronQty; ++i){
				for (int j=0; j<=trib.iNeuronQty; ++j){
					//lay.Weights[i][j]=lay.cdcAltWeights[i][j]; ++iReturn;
					lay.ZOutputs[i] = CxAddCx( lay.ZOutputs[i], CxMultiplyCx(lay.Weights[IDX2C(i,j,lay.iNeuronQty+1)] , trib.ZOutputs[j]) );
				}
			}
			/* layer is complete. */
		}
		 /* backprop is complete. */
	}
	 /* for(int i=1; i<=rSes.rLearn->iOutputQty; ++i){  /* loop over outputs
	 /* 	double dDelta = (double) abs( sam.dXInputs[rSes.rLearn->iInputQty+i] - sam.dYEval[i] );
	 /* 	printf("%f ", dDelta);
	 /* }
	 /* printf("\n");. */
	for(int i=1; i<=top.iNeuronQty; ++i){
		 /* delta-star = D - Y = Desired output minus actual output from evaluation
		 /* D is the cplx coords of the sector of the desired answer		Y is the complex result of evaluation of the given sample. */
		Deltastar = CxSubtractCx( rSes.rNet->cdcSectorBdry[(int) rSes.rLearn->dDOutputs[ IDX2C( i, lSampleIdxReq, rSes.rLearn->iOutputQty+1 ) ]], 
			top.ZOutputs[i] );
		 /* printf("after : % 1f+% 1fi = % 1f+% 1fi - % 1f+% 1fi\n", Deltastar.x, Deltastar.y, 
			 /* rSes.rNet->cdcSectorBdry[(int) sam.dXInputs[ rSes.rLearn->iInputQty+i ]].x, rSes.rNet->cdcSectorBdry[(int) sam.dXInputs[ rSes.rLearn->iInputQty+i ]].y,
			 /* top.ZOutputs[i].x, top.ZOutputs[i].y);. */
	}
	
	return iReturn; /* number of weights updated. */
}

int TrainNNThresh(struct rohanContext& rSes, long bChangeWeights)
{mIDfunc 
/*! checks sampled outputs vs evaluated outputs, and returns number of samples that exceed threshold
 *  excessive samples are submitted for backpropagation if bChangeWeights is true.
 */
	int iReturn=0;
	double dDelta=0;
	long ROWLEN = rSes.rLearn->iOutputQty+1 ;

	if (rSes.lSampleQtyReq<=0 || rSes.lSampleQtyReq>rSes.rLearn->lSampleQty)
		rSes.lSampleQtyReq=rSes.rLearn->lSampleQty;
	//adjust requested amount to available values
	for(long s=0; s<rSes.lSampleQtyReq; ++s){  // loop over samples.
		//struct rohanSample& sam = rSes.rLearn->rSample[s];
		int iOverMAX=0;
		for(int i=0; i<=rSes.rLearn->iOutputQty; ++i){  // loop over outputs.
			dDelta = (double) abs( rSes.rLearn->dDOutputs[ IDX2C( i, s, ROWLEN ) ] - rSes.rLearn->dYEval[ IDX2C( i, s, ROWLEN ) ] );
			 // printf("dDelta %f dDelta*2 %f, Sectors %d\n", dDelta, dDelta*2, rSes.rNet->iSectorQty);
			if((dDelta*2)>rSes.rNet->iSectorQty)
				dDelta=rSes.rNet->iSectorQty-dDelta;
			 // printf("Sample %d, output %f eval %f delta %f\n", s, sam.dXInputs[rSes.rLearn->iInputQty+i], sam.dYEval[i], dDelta);
			if( dDelta > rSes.dMAX)  // if effective error exceeds MAX, make a note
				++iOverMAX;
		}
		if (iOverMAX!=0) {	 // if a note has been made. 
			++iReturn; // increment the number of excessive samples.
			if (bChangeWeights) {  // and correct weights if that is desired.
				cuBackpropSingleSample(rSes, s);
				//devBackpropSingleSample(rSes, s);
				//dualBackpropSingleSample(rSes, s);
			}
		}
	}
	return (iReturn);
}


double RmseNN(struct rohanContext& rSes, long lSampleQtyReq)
{mIDfunc /*! checks sampled outputs vs evaluated outputs and calculates root mean squared error. */
	double dReturn=0;
	FILE *fShow=rSes.debugHandle;
	// check if sample qty is outside the meaningful interval [1, all]
	if(lSampleQtyReq<=0 || lSampleQtyReq>rSes.rLearn->lSampleQty)
		lSampleQtyReq=rSes.rLearn->lSampleQty; // default to all if so
	for(long s=0; s<lSampleQtyReq; ++s){
		//struct rohanSample& sam = rSes.rLearn->rSample[s]; // loop over all requested samples and documented outputs
		for(int i=1; i<=rSes.rLearn->iOutputQty; ++i){
			double dDelta = (double)abs( rSes.rLearn->dDOutputs[IDX2C( i, s, (rSes.rLearn->iOutputQty+1))] - rSes.rLearn->dYEval[IDX2C( i, s, (rSes.rLearn->iOutputQty+1))] ); // delta = Desired - Yielded values
			if(dDelta>(double)(rSes.rNet->iSectorQty/2)) 
				dDelta=((double)rSes.rNet->iSectorQty-dDelta); // set delta to the lesser arc length
			dReturn+=(dDelta*dDelta); // accumulate squared error 
		}
	}
	dReturn=sqrt(dReturn/(double)(lSampleQtyReq*rSes.rLearn->iOutputQty)); // take the root of the mean of the accumulated square error
	
	printf(">>>RmseNN %f\n", dReturn);
	return dReturn;
}
