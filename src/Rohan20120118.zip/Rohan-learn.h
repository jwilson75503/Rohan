/* Includes, cuda */

#include "Rohan.h"

////int devSetInputs(struct rohanContext& rSes, int iLayer);

////int devActivate(struct rohanContext& rSes, int iLayer);

////int devEvalSingleSample(struct rohanContext& rSes, long lSampleIdxReq);

int dualEvalSingleSample(struct rohanContext& rSes, long lSampleIdxReq)
;

int cuEvalSingleSample(struct rohanContext& rSes, long lSampleIdxReq)
;

int cuEvalSingleOutput(rohanContext& rSes, long lSampleIdxReq, int iOutputIdxReq)
;

long OutputValidate(rohanContext& rSes)
;

////int devResetAllDeltasAndOutputs(struct rohanContext& rSes);

int cuResetAllDeltasAndOutputs(struct rohanContext& rSes)
;

////int devBackpropSingleSample(rohanContext& rSes, long lSampleIdxReq);

int dualBackpropSingleSample(struct rohanContext& rSes, long lSampleIdxReq)
;

int cuBackpropSingleSample(struct rohanContext& rSes, long lSampleIdxReq)
;

int TrainNNThresh(struct rohanContext& rSes, long bChangeWeights)
;

double RmseNN(struct rohanContext& rSes, long lSampleQtyReq)
;

