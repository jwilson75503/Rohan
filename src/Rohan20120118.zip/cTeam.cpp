#include "Rohan.h"
#include "Rohan-data.h"
#include "Rohan-io.h"
#include "Rohan-learn.h"
#include "Rohan-menu.h"
#include "Rohan-kernel.h"
#include "Rohan-class.h"

#include "cTeam.h"
#include "ShowMe.h"
#include "stdafx.h"
#include "crc.h"
#include <conio.h> //for _getch 

#include <cuda.h>

#include <cutil_inline.h>
#include <cuda_runtime_api.h>
#include <multithreading.h>

//#include <time.h> // for tsrtuct
#include <sys/timeb.h>
#include <iostream>
#include <stdlib.h>
using namespace std;
using std::cin;
using std::cout;

#define TWO_PI 6.283185307179586476925286766558
#define IDX2C( i, j, ld) ((i)+(( j )*( ld )))

extern int iDebugLvl, iWarnings, iErrors, iTrace;
extern long bCUDAavailable;


//long cTeam::LetHitch(struct rohanContext& rSes)
//{mIDfunc
//	printf("cTeam is now hitched. You should not see this.\n");
//	return 0;
//}
//
//long cTeam::LetUnHitch(struct rohanContext& rSes)
//{mIDfunc
//	printf("cTeam unhitched. You should not see this.\n");
//	return 0;
//}
//
//long cTeam::SetStopCriteria( long lIterationQty, double dRMSE)
//{mIDfunc/// specifies conditions for end of training task
//	rSes->dTargRMSE=dRMSE;
//	rSes->iEpochLength=lIterationQty;
//
//	return 0;
//}

//
////////////////// class cHostTeam begins ////////////////
//
//void cHostTeam::ShowMe()
//{mIDfunc
//	//ShowMeSes(* rSes, false);
//	printf("I'm a stubborn mule!\n");
//}
//
//long cHostTeam::GetEvalSingleSample( struct rohanContext& rSes, long lSampleIdxReq, char chMethod)
//{mIDfunc/*! calculates NN outputs for a given sample with serial method */
//	return cuEvalSingleSample(rSes, lSampleIdxReq);
//}
//
//long cHostTeam::LetBackpropSingleSample( rohanContext& rSes, long lSampleIdxReq, char chMethod)
//{mIDfunc/// Placeholder
//	return cuBackpropSingleSample(rSes, lSampleIdxReq);
//}


//////////////// class cDeviceTeam begins ////////////////

cDeviceTeam::cDeviceTeam( struct rohanContext& rSes)//, struct rohanNetwork& rNet, rohanLearningSet& rLearn)
{mIDfunc
	SetContext(rSes); // attach to host-side data structures
	SetNetwork(*rSes.rNet);
	SetSamples(*rSes.rLearn);

	// informally acknowledge class
	ShowMe();
	//const char* const classname = "cDeviceTeam";
}

long cDeviceTeam::SetContext( rohanContext& rC)
{mIDfunc/// enables pointer access to master context struct
	rSes = &rC;
	return 0;
}

long cDeviceTeam::SetNetwork( rohanNetwork& rN)
{mIDfunc/// enables pointer access to weight sets and layer sizes, etc
	rNet = &rN;
	return 0;
}

long cDeviceTeam::SetSamples( rohanLearningSet& rL)
{mIDfunc/// enables pointer access to master sample struct
	rLearn = &rL;
	return 0;
}

long cDeviceTeam::SetBarge( class cBarge * cbBarge)
{mIDfunc/// enables pointer access to active Barge object
	Barge = cbBarge;
	return 0;
}

long cDeviceTeam::SetDrover( class cDrover * cdDrover)
{mIDfunc/// enables pointer access to active Drover object
	Drover = cdDrover;
	return 0;
}


void cDeviceTeam::ShowMe()
{mIDfunc
	//ShowMeSes(* rSes, false);
	printf("I'm a mighty stallion!\n");
}

long cDeviceTeam::LetEvalSet( rohanContext& rS, long lSampleQtyReq, char chMethod)
{mIDfunc/// Submits a subset of the samples available forevaluation.
	/// Size of the subet is controlled by lSampleQtyReq
	long lFinalSample;
	// check request is not too large or too small
	if (0<lSampleQtyReq && lSampleQtyReq<rS.rLearn->lSampleQty)
		lFinalSample=lSampleQtyReq;
	else
		lFinalSample=rS.rLearn->lSampleQty;
	// proceed with submission loop		
	for (long i=0; i<lFinalSample; ++i){
		if(chMethod=='c')
			return cuEvalSingleSample(rS, i);
		else // d for GPU device
			return 0;////return devEvalSingleSample(rS, i);
	}
	return lFinalSample;
}

long cDeviceTeam::LetTrainNNThresh( rohanContext& rS, long lSampleQtyReq, char chMethod)
{mIDfunc/// Submits a subset of the samples available for backprop learning.
	/// Size of the subet is controlled by lSampleQtyReq
	long lFinalSample;
	// check request is not too large or too small
	if (0<lSampleQtyReq && lSampleQtyReq<rS.rLearn->lSampleQty)
		lFinalSample=lSampleQtyReq;
	else
		lFinalSample=rS.rLearn->lSampleQty;
	// proceed with submission loop		
	for (long i=0; i<lFinalSample; ++i)
		LetBackpropSingleSample(rS, i, chMethod);
	return lFinalSample;
}

long cDeviceTeam::LetBackpropSingleSample( rohanContext& rSes, long lSampleIdxReq, char chMethod)
{mIDfunc
	return 0;
}

double cDeviceTeam::GetRmseNN(struct rohanContext& rSes, long lSampleQtyReq)
{mIDfunc/*! checks sampled outputs vs evaluated outputs and calculates root mean squared error. */
	
	return knlRMSEopt( rSes, 0,0, 'R');
}

long cDeviceTeam::LetHitch(struct rohanContext& rSes)    
{mIDfunc/*! \callgraph \callergraph copy data to device memory space and attach structures to Team */
	printf("cDeviceTeam begin hitch process.\n");

	// BEGIN context data structure members
 	TransferContext(rSes, 'D');
	
	/*! BEGIN network architecture structure members */
	CopyNet( rSes, 'D' );
	
	/*! BEGIN learning set structure members */
	CopyLearnSet(rSes, 'D');
	
	/// end members and structures
	printf("cDeviceTeam is now hitched.\n");
		
	return 0;
}


long cDeviceTeam::TransferContext(struct rohanContext& rSes, char Direction)
{mIDfunc/*! copy rSes 0D members to dev mem */
	cudaMemcpyKind kind=cudaMemcpyHostToDevice;
	
	printf("=> Transfer Context %c =>\n", Direction);
	long SIZE = sizeof(rSes);
	//printf("%08lX %7ld %s\n", crc32buf( (char*)&rSes, SIZE ), SIZE, "rSes");
	
	if(Direction=='D'||Direction=='d') {
		// publish Context structure to device
		rSes.iEpochLength=99999;
		//printf("%08lX %7ld %s\n", crc32buf( (char*)&rSes, SIZE ), SIZE, "rSes");
		//printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rSes.devSes, SIZE ), SIZE, "devSes");
		//ShowMeSes(rSes,0);
		cudaMemcpyToSymbol( "devSes", &rSes, sizeof(rSes) );
			mCheckCudaWorked
		//knlXferSesD(&rSes);
		//printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rSes.devSes, SIZE ), SIZE, "devSes");
	}
	else {
		// retrieve rdSes from device
		cudaMemcpyFromSymbol( &rSes, "devSes", sizeof(rSes) );
			mCheckCudaWorked
		printf("%08lX %7ld %s\n", crc32buf( (char*)&rSes, SIZE ), SIZE, "rSes");
	}
	if(crc32buf( (char*)&rSes, SIZE )==knlCRC32Buf( (char*)rSes.devSes, SIZE ))
		printf("context faithfully copied\n");
	else
		printf("FAILURE copying context\n");

	return 0;
}

long cDeviceTeam::CopyNet(struct rohanContext& rSes, char Direction)
{mIDfunc/*! copy NN arch and layer structures, their contents, and member values to dev memory */
	cudaMemcpyKind kind; //cuDoubleComplex * dummy;
	struct rohanNetwork * rnSrc, * rnDest ;
	struct rohanLayer * rlSrc;
	long LQTY, LLAST, LSIZE, SECSIZE;

	printf("=> Copy Network %c =>\n", Direction);
	rnSrc=(rSes.rNet);
	long SIZE = sizeof(*rSes.rNet);
	//printf("%08lX %7ld %s\n", crc32buf( (char*)rnSrc, SIZE ), SIZE, "rNet");
		
	cudaGetSymbolAddress( (void**)&rnDest, "devNet" ); /*! get ptr into devspace for network structure */
		mCheckCudaWorked
	LQTY = rnSrc->iLayerQty ; 
		LLAST = LQTY - 1 ;
	LSIZE = sizeof(rohanLayer) * LQTY ;
	kind=cudaMemcpyHostToDevice;
	long DQTY, NQTY, WQTY, DSIZE, NSIZE, WSIZE;

	//gpuZOutputs - layer zero
	NQTY = rnSrc->rLayer[0].iNeuronQty + 1 ; // neurons = outgoing signals
	NSIZE = NQTY * sizeof(cuDoubleComplex) ;
	rlSrc=&(rSes.rNet->rLayer[0]);
	cudaMalloc( (void**)&rlSrc->gpuZOutputs, NSIZE ); /*! mold devspace for output aignals */
		mCheckCudaWorked
	cudaMemcpy( rlSrc->gpuZOutputs, rlSrc->ZOutputs, NSIZE, kind); /*! fill the devspace mold with hostspace values */
		mCheckCudaWorked
	printf("layer %d molded and filled?\n", 0);

	for (long L=1; L<=LLAST; ++L){
		//printf("----> Copy Layer %d %c ---->\n", L, Direction);
		//setup dimension values
		DQTY = rnSrc->rLayer[L].iDendriteQty + 1 ; // dendrites = incoming signals
		DSIZE = DQTY * sizeof(cuDoubleComplex) ;
		NQTY = rnSrc->rLayer[L].iNeuronQty + 1 ; // neurons = outgoing signals
		NSIZE = NQTY * sizeof(cuDoubleComplex) ;
		WQTY = DQTY * NQTY ; // weights = weights
		WSIZE = WQTY * sizeof(cuDoubleComplex) ;
		rlSrc=&(rSes.rNet->rLayer[L]);
		
		//gpuWeights
		cudaMalloc( (void**)&rlSrc->gpuWeights, WSIZE ); /*! mold devspace for weights  */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpuWeights, rlSrc->Weights, WSIZE, kind); /*! fill the devspace mold with hostspace values */
			mCheckCudaWorked
		//gpuXInputs
		cudaMalloc( (void**)&rlSrc->gpuXInputs, DSIZE ); /*! mold devspace for input aignals */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpuXInputs, rlSrc->XInputs, DSIZE, kind); /*! fill the devspace mold with hostspace values */
			mCheckCudaWorked
		//gpuZOutputs
		cudaMalloc( (void**)&rlSrc->gpuZOutputs, NSIZE ); /*! mold devspace for output aignals */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpuZOutputs, rlSrc->ZOutputs, NSIZE, kind); /*! fill the devspace mold with hostspace values */
			mCheckCudaWorked
		//gpuDeltas 
		cudaMalloc( (void**)&rlSrc->gpuDeltas, WSIZE ); /*! mold devspace for weight adjustments */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpuDeltas, rlSrc->Deltas, WSIZE, kind); /*! fill the devspace mold with hostspace values */
			mCheckCudaWorked
		printf("layer %d molded and filled?\n", L);
	}
	
	// mold dev memspace for layers and copy contents
	cudaMalloc( (void**)&rnSrc->gpuLayer, LSIZE );
		mCheckCudaWorked
	cudaMemcpy( rnSrc->gpuLayer, rnSrc->rLayer, LSIZE , kind );
		mCheckCudaWorked

	//printf("%08lX %7ld %s\n", crc32buf( (char*)rnSrc->rLayer, LSIZE ), LSIZE, "rLayer");
	//printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rnSrc->gpuLayer, LSIZE ), LSIZE, "gpuLayer");
	if(crc32buf( (char*)rnSrc->rLayer, LSIZE )==knlCRC32Buf( (char*)rnSrc->gpuLayer, LSIZE ))
		printf("%d layer heads faithfully copied\n", LQTY);
	else
		printf("FAILURE copying layer heads\n");
		
	// mold dev memspace for sector table and copy contents
	SECSIZE = rnSrc->iSectorQty * sizeof(cuDoubleComplex);
	cudaMalloc( (void**)&rnSrc->gpuSectorBdry, SECSIZE );
		mCheckCudaWorked
	cudaMemcpy( rnSrc->gpuSectorBdry, rnSrc->cdcSectorBdry, SECSIZE , kind );
		mCheckCudaWorked
	if(crc32buf( (char*)rnSrc->cdcSectorBdry, SECSIZE )==knlCRC32Buf( (char*)rnSrc->gpuSectorBdry, SECSIZE ))
		printf("sector table faithfully copied\n");
	else
		printf("FAILURE copying sector table\n");

	//rNet->iSectorQty=55555;
	//ShowMeArch(rSes,0);
	//printf("%08lX %7ld %s\n", crc32buf( (char*)rnSrc, SIZE ), SIZE, "rNet");
	//printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rSes.devNet, SIZE ), SIZE, "devNet");
	cudaMemcpyToSymbol( "devNet", rSes.rNet, sizeof(*rSes.rNet) ); //, 0, kind );
		mCheckCudaWorked
	//printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rSes.devNet, SIZE ), SIZE, "devNet");
	//knlShowMeNet();
	if(crc32buf( (char*)rnSrc, SIZE )==knlCRC32Buf( (char*)rSes.devNet, SIZE ))
		printf("net params faithfully copied\n");
	else
		printf("FAILURE copying net params\n");

	return 0;
}

long cDeviceTeam::CopyLearnSet(struct rohanContext& rSes, char Direction)
{mIDfunc/*! copies learning set structures, contents, andvmember values to device memory space */
	cudaMemcpyKind kind; //cuDoubleComplex * dummy;
	struct rohanLearningSet * rlSrc;
	long IQTY, OQTY, INSIZED, OUTSIZED, INSIZECX, OUTSIZECX;
	
	//setup dimension values
	IQTY = rSes.rLearn->iInputQty+1 ;
	INSIZED = rSes.rLearn->lSampleQty * ( IQTY ) * sizeof(double) ;
	INSIZECX = rSes.rLearn->lSampleQty * ( IQTY ) * sizeof(cuDoubleComplex) ;
	OQTY = rSes.rLearn->iOutputQty+1; 
	OUTSIZED = rSes.rLearn->lSampleQty * ( OQTY ) * sizeof(double);
	OUTSIZECX = rSes.rLearn->lSampleQty * ( OQTY ) * sizeof(cuDoubleComplex);
	
	printf("=> Copy Learning Set %c =>\n", Direction);
	rlSrc=(rSes.rLearn);
	long SIZE = sizeof(*rSes.rLearn);
	//printf("%08lX %7ld %s\n", crc32buf( (char*)rlSrc, SIZE ), SIZE, "rLearn");
	
	if(Direction=='D'||Direction=='d') {
		kind=cudaMemcpyHostToDevice;
		// gpudXInputs
		cudaMalloc( (void**)&rlSrc->gpudXInputs, INSIZED ); /*! mold devspace for scalar input signals */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpudXInputs, rlSrc->dXInputs, INSIZED, kind); /*! fill the devspace mold with hostspace values */
			mCheckCudaWorked
		// gpudDOutputs
		cudaMalloc( (void**)&rlSrc->gpudDOutputs, OUTSIZED ); /*! 2D desired scalar outputs in GPU. */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpudDOutputs, rlSrc->dDOutputs, OUTSIZED, kind); 
			mCheckCudaWorked
		// gpudYEval
		cudaMalloc( (void**)&rlSrc->gpudYEval, OUTSIZED ); /*! 2D yielded scalar outputs in GPU. */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpudYEval, rlSrc->dYEval, OUTSIZED, kind); 
			mCheckCudaWorked
		// gpudAltYEval
		cudaMalloc( (void**)&rlSrc->gpudAltYEval, OUTSIZED ); /*! 2D yielded scalar outputs in GPU. */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpudAltYEval, rlSrc->dAltYEval, OUTSIZED, kind); 
			mCheckCudaWorked
		// gpudSE1024
		cudaMalloc( (void**)&rlSrc->gpudSE1024, OUTSIZED ); /* array for intermediate RMSE totals, changed from 1024 to OUTSIZED on 1/8/12 */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpudSE1024, rlSrc->dSE1024, OUTSIZED , kind );
			mCheckCudaWorked
		// gpuXInputs
		cudaMalloc( (void**)&rlSrc->gpuXInputs, INSIZECX ); /*! mold devspace for complex input signals */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpuXInputs, rlSrc->cdcXInputs, INSIZECX, kind); /*! fill the devspace mold with hostspace values */
			mCheckCudaWorked
		// gpuDOutputs
		cudaMalloc( (void**)&rlSrc->gpuDOutputs, OUTSIZECX ); /*! 2D desired complex outputs in GPU. */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpuDOutputs, rlSrc->cdcDOutputs, OUTSIZECX, kind); 
			mCheckCudaWorked
		// gpuYEval
		cudaMalloc( (void**)&rlSrc->gpuYEval, OUTSIZECX ); /*! 2D yielded complex outputs in GPU. */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpuYEval, rlSrc->cdcYEval, OUTSIZECX, kind); 
			mCheckCudaWorked
		// gpuAltYEval
		cudaMalloc( (void**)&rlSrc->gpuAltYEval, OUTSIZECX ); /*! 2D yielded complex outputs in GPU. */
			mCheckCudaWorked
		cudaMemcpy( rlSrc->gpuAltYEval, rlSrc->cdcAltYEval, OUTSIZECX, kind); 
			mCheckCudaWorked
		
		if(0){ // checksums to verify faithful transfer
			printf("%08lX %7ld %s\n", crc32buf( (char*)rlSrc->dXInputs, INSIZED ), INSIZED, "dXInputs");
			printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rlSrc->gpudXInputs, INSIZED ), INSIZED, "gpudXInputs");
			printf("%08lX %7ld %s\n", crc32buf( (char*)rlSrc->dDOutputs, OUTSIZED ), OUTSIZED, "dDOutputs");
			printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rlSrc->gpudDOutputs, OUTSIZED ), OUTSIZED, "gpudDOutputs");
			printf("%08lX %7ld %s\n", crc32buf( (char*)rlSrc->dYEval, OUTSIZED ), OUTSIZED, "dYEval");
			printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rlSrc->gpudYEval, OUTSIZED ), OUTSIZED, "gpudYEval");
			printf("%08lX %7ld %s\n", crc32buf( (char*)rlSrc->dAltYEval, OUTSIZED ), OUTSIZED, "dAltYEval");
			printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rlSrc->gpudAltYEval, OUTSIZED ), OUTSIZED, "gpudAltYeval");
			printf("%08lX %7ld %s\n", crc32buf( (char*)rlSrc->dSE1024, OUTSIZED ), OUTSIZED, "dSE1024"); // mades OUTSIZED by JAW 1/8/12
			printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rlSrc->gpudSE1024, OUTSIZED ), OUTSIZED, "gpudSE102");
		}
		// store array dimensions
		rSes.rLearn->IQTY=IQTY;
		rSes.rLearn->OQTY=OQTY;
		rSes.rLearn->INSIZED=INSIZED;
		rSes.rLearn->OUTSIZED=OUTSIZED;
		rSes.rLearn->INSIZECX=INSIZECX;
		rSes.rLearn->OUTSIZECX=OUTSIZECX;
		
		// publish Learn struct to device
		rSes.rLearn->lSampleIdxReq=77777;
		
		//printf("%08lX %7ld %s\n", crc32buf( (char*)rlSrc, SIZE ), SIZE, "rLearn");
		//printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rSes.devLearn, SIZE ), SIZE, "devLearn");
		
		//ShowMeLS(rSes, 0);
		
		cudaMemcpyToSymbol( "devLearn", rSes.rLearn, sizeof(*rSes.rLearn) ); //, 0, kind );
			mCheckCudaWorked
		//printf("%08lX %7ld %s\n", knlCRC32Buf( (char*)rSes.devLearn, SIZE ), SIZE, "devLearn");
	}
	else {
		kind=cudaMemcpyDeviceToHost;
	}
	if(crc32buf( (char*)rlSrc, SIZE )==knlCRC32Buf( (char*)rSes.devLearn, SIZE ))
		printf("samples faithfully copied\n");
	else
		printf("FAILURE copying samples\n");

	return 0;
}

long cDeviceTeam::LetUnHitch(struct rohanContext& rSes)
{mIDfunc/*! \callgraph \callergraph free device memory structures to Team */
	
	// BEGIN free nw data structures
	struct rohanNetwork * rnSrc=(rSes.rNet);
	long LLAST = rnSrc->iLayerQty - 1 ;
	for (long L=1; L<=LLAST; ++L){
		struct rohanLayer * rlSrc = &rSes.rNet->rLayer[L] ;
		cudaFree( rlSrc->gpuWeights);
			mCheckCudaWorked
		cudaFree( rlSrc->gpuXInputs);
			mCheckCudaWorked
		cudaFree( rlSrc->gpuZOutputs);
			mCheckCudaWorked
		cudaFree( rlSrc->gpuDeltas);
			mCheckCudaWorked
		printf("cdt: Layer %d clear\n", L);
	}
	cudaFree( rnSrc->gpuLayer);
		mCheckCudaWorked
	cudaFree( rnSrc->gpuSectorBdry);
		mCheckCudaWorked
	printf("cdt: Net Arch clear\n");	

	//BEGIN freeing rdLearn structures
	struct rohanLearningSet * rlSrc = rSes.rLearn;
		cudaFree( rlSrc->gpudXInputs);
			mCheckCudaWorked
		cudaFree( rlSrc->gpudDOutputs);
			mCheckCudaWorked
		cudaFree( rlSrc->gpudYEval);
			mCheckCudaWorked
		cudaFree( rlSrc->gpudAltYEval);
			mCheckCudaWorked
		cudaFree( rlSrc->gpudSE1024);
			mCheckCudaWorked
		cudaFree( rlSrc->gpuXInputs);
			mCheckCudaWorked
		cudaFree( rlSrc->gpuDOutputs);
			mCheckCudaWorked
		cudaFree( rlSrc->gpuYEval);
			mCheckCudaWorked
		cudaFree( rlSrc->gpuAltYEval);
			mCheckCudaWorked
	printf("cdt: LearnSet clear\n");

	/// end members and structures
	printf("cDeviceTeam unhitched.\n");

	return 0;
}


//double cDeviceTeam::GetRmseNN(struct rohanContext& rSes, long lSampleQtyReq)
//{mIDfunc/*! checks sampled outputs vs evaluated outputs and calculates root mean squared error. */
//	double RMSE=0.0;
//	
//	if (lSampleQtyReq<=1 || lSampleQtyReq> rSes.rLearn->lSampleQty )
//		lSampleQtyReq=rSes.rLearn->lSampleQty;
//	LetTaut(rSes);
//	knlTest();
//	RMSE=knlRMSEnew(rdSes, rdLearn, rdNet, lSampleQtyReq);
//	knlTest();
//	LetSlack(rSes);
//	return RMSE;
//}


long cDeviceTeam::LetTaut(struct rohanContext& rSes)
{mIDfunc/*! \callgraph \callergraph update dev mem from host for epoch */;
	TransferContext(rSes, 'D');
	TransferLayers(rSes, 'D');
	printf("Tautening...\n");
	return 0;
}


long cDeviceTeam::TransferLayers(struct rohanContext& rSes, char Direction)
{mIDfunc/*! \callgraph \callergraph copy rNet layer data to dev mem */
	cudaMemcpyKind kind; //cuDoubleComplex * dummy;
	struct rohanNetwork * rnSrc, * rnDest ;
	struct rohanLayer * rlSrc;
	long LQTY, LLAST, LSIZE;

	rnSrc=(rSes.rNet);
	long SIZE = sizeof(*rSes.rNet);
	//printf("%08lX %7ld %s\n", crc32buf( (char*)rnSrc, SIZE ), SIZE, "rNet");
		
	cudaGetSymbolAddress( (void**)&rnDest, "devNet" ); /*! get ptr into devspace for network structure */
		mCheckCudaWorked
	LQTY = rnSrc->iLayerQty ; 
		LLAST = LQTY - 1 ;
	LSIZE = sizeof(rohanLayer) * LQTY ;

	if (Direction=='D' || Direction=='D'){
		kind=cudaMemcpyHostToDevice;
		for (long L=1; L<=LLAST; ++L){
			//printf("----> Copy Layer %d %c ---->\n", L, Direction);
			long DQTY, NQTY, WQTY, DSIZE, NSIZE, WSIZE;
			//setup dimension values
			DQTY = rnSrc->rLayer[L].iDendriteQty + 1 ; // dendrites = incoming signals
			DSIZE = DQTY * sizeof(cuDoubleComplex) ;
			NQTY = rnSrc->rLayer[L].iNeuronQty + 1 ; // neurons = outgoing signals
			NSIZE = NQTY * sizeof(cuDoubleComplex) ;
			WQTY = DQTY * NQTY ; // weights = weights
			WSIZE = WQTY * sizeof(cuDoubleComplex) ;
			rlSrc=&(rSes.rNet->rLayer[L]);
			//gpuWeights
			cudaMemcpy( rlSrc->gpuWeights, rlSrc->Weights, WSIZE, kind); /*! fill the devspace mold with hostspace values */
				mCheckCudaWorked
			//gpuXInputs
			cudaMemcpy( rlSrc->gpuXInputs, rlSrc->XInputs, DSIZE, kind); /*! fill the devspace mold with hostspace values */
				mCheckCudaWorked
			//gpuZOutputs
			cudaMemcpy( rlSrc->gpuZOutputs, rlSrc->ZOutputs, NSIZE, kind); /*! fill the devspace mold with hostspace values */
				mCheckCudaWorked
			//gpuDeltas 
			cudaMemcpy( rlSrc->gpuDeltas, rlSrc->Deltas, WSIZE, kind); /*! fill the devspace mold with hostspace values */
				mCheckCudaWorked
			printf("-> layer %d transferred?\n", L);
		}
	}
	else{
		kind=cudaMemcpyDeviceToHost;
		for (long L=1; L<=LLAST; ++L){
			//printf("----> Copy Layer %d %c ---->\n", L, Direction);
			long DQTY, NQTY, WQTY, DSIZE, NSIZE, WSIZE;
			//setup dimension values
			DQTY = rnSrc->rLayer[L].iDendriteQty + 1 ; // dendrites = incoming signals
			DSIZE = DQTY * sizeof(cuDoubleComplex) ;
			NQTY = rnSrc->rLayer[L].iNeuronQty + 1 ; // neurons = outgoing signals
			NSIZE = NQTY * sizeof(cuDoubleComplex) ;
			WQTY = DQTY * NQTY ; // weights = weights
			WSIZE = WQTY * sizeof(cuDoubleComplex) ;
			rlSrc=&(rSes.rNet->rLayer[L]);
			//gpuWeights
			cudaMemcpy( rlSrc->Weights, rlSrc->gpuWeights, WSIZE, kind); /*! fill the devspace mold with hostspace values */
				mCheckCudaWorked
			//gpuXInputs
			cudaMemcpy( rlSrc->XInputs, rlSrc->gpuXInputs, DSIZE, kind); /*! fill the devspace mold with hostspace values */
				mCheckCudaWorked
			//gpuZOutputs
			cudaMemcpy( rlSrc->ZOutputs, rlSrc->gpuZOutputs, NSIZE, kind); /*! fill the devspace mold with hostspace values */
				mCheckCudaWorked
			//gpuDeltas 
			cudaMemcpy( rlSrc->Deltas, rlSrc->gpuDeltas, WSIZE, kind); /*! fill the devspace mold with hostspace values */
				mCheckCudaWorked
			printf("-> layer %d transferred?\n", L);
		}
	}
	printf("cdt: Layers (weights only) copied %c\n", Direction);
	
	return 0;
}


long cDeviceTeam::LetSlack(struct rohanContext& rSes)
{mIDfunc/*! \callgraph \callergraph update dev mem from host for epoch */;
	TransferContext(rSes, 'H');
	TransferLayers(rSes, 'H');
	TransferOutputs(rSes, 'H');
	printf("...slackening.\n");
	return 0;
}


long cDeviceTeam::TransferOutputs(struct rohanContext& rSes, char Direction)
{mIDfunc/*! transfers contents of yielded output data strctures between memory spaces, usually dev to host */
	cudaMemcpyKind kind; //cuDoubleComplex * dummy;
	struct rohanLearningSet * rlSrc;
	long IQTY, OQTY, INSIZED, OUTSIZED, INSIZECX, OUTSIZECX;
	
	//setup dimension values
	IQTY = rSes.rLearn->iInputQty+1 ;
	INSIZED = rSes.rLearn->lSampleQty * ( IQTY ) * sizeof(double) ;
	INSIZECX = rSes.rLearn->lSampleQty * ( IQTY ) * sizeof(cuDoubleComplex) ;
	OQTY = rSes.rLearn->iOutputQty+1; 
	OUTSIZED = rSes.rLearn->lSampleQty * ( OQTY ) * sizeof(double);
	OUTSIZECX = rSes.rLearn->lSampleQty * ( OQTY ) * sizeof(cuDoubleComplex);
	
	rlSrc=(rSes.rLearn);

	if(Direction=='D'||Direction=='d') {
		kind=cudaMemcpyHostToDevice; // CPU plain evals go to GPU alt evals
		// gpudYEval
		//cudaMemcpy( rlSrc->gpudYEval, rlSrc->dYEval, OUTSIZED, kind); 
		//	mCheckCudaWorked
		// gpudAltYEval
		cudaMemcpy( rlSrc->gpudAltYEval, rlSrc->dYEval, OUTSIZED, kind); 
			mCheckCudaWorked
		// gpuYEval
		//cudaMemcpy( rlSrc->gpuYEval, rlSrc->cdcYEval, OUTSIZECX, kind); 
		//	mCheckCudaWorked
		// gpuAltYEval
		cudaMemcpy( rlSrc->gpuAltYEval, rlSrc->cdcYEval, OUTSIZECX, kind); 
			mCheckCudaWorked
	}
	else {
		kind=cudaMemcpyDeviceToHost; // GPU plain evals go to CPU alt evals
		cudaMemcpy( rlSrc->dAltYEval, rlSrc->gpudYEval, OUTSIZED, kind); 
			mCheckCudaWorked
		cudaMemcpy( rlSrc->cdcAltYEval, rlSrc->gpuYEval, OUTSIZECX, kind); 
			mCheckCudaWorked
	}

	return 0;
}

long cDeviceTeam::GetEvalSingleSample( struct rohanContext& rSes, long lSampleIdxReq, char chMethod)
{mIDfunc/*! calculates NN outputs for a given sample with GPU method */
	if(chMethod=='c')
		return cuEvalSingleSample(rSes, lSampleIdxReq);
	else // d for GPU device
		return 0;////return devEvalSingleSample(rSes, lSampleIdxReq);
}

//long cDeviceTeam::LetBackpropSingleSample( rohanContext& rSes, long lSampleIdxReq, char chMethod)
//{mIDfunc
//	if(chMethod=='c')
//		return cuBackpropSingleSample(rSes, lSampleIdxReq);
//	else // d for GPU device
//		return 0; ////devBackpropSingleSample(rSes, lSampleIdxReq);
//}

//////////////// class cDualTeam begins ////////////////
//
//void cDualTeam::ShowMe()
//{mIDfunc
//	//ShowMeSes(* rSes, false);
//	printf("I'm a Y adaptor!\n");
//}
//
//long cDualTeam::GetEvalSingleSample( struct rohanContext& rSes, long lSampleIdxReq, char chMethod)
//{mIDfunc/*! calculates NN outputs for a given sample with GPU method */
//	if(chMethod=='c')
//		return cuEvalSingleSample(rSes, lSampleIdxReq);
//	else // d for GPU device
//		return 0;////return devEvalSingleSample(rSes, lSampleIdxReq);
//}
//
//long cDualTeam::LetBackpropSingleSample( rohanContext& rSes, long lSampleIdxReq, char chMethod)
//{mIDfunc
//	if(chMethod=='c')
//		return cuBackpropSingleSample(rSes, lSampleIdxReq);
//	else // d for GPU device
//		return 0; ////devBackpropSingleSample(rSes, lSampleIdxReq);
//}
//
