#include "Rohan.h"
#include "Rohan-data.h"
#include "Rohan-io.h"
#include "Rohan-learn.h"
#include "Rohan-menu.h"
#include "Rohan-kernel.h"
#include "Rohan-class.h"
#include "cTeam.h"
#include "ShowMe.h"
#include "stdafx.h"
#include <conio.h> //for _getch 
#include <cuda.h>
// Shared Utilities (QA Testing)
#include <shrUtils.h>
#include <shrQATest.h>
#include <cuda.h>
#include <cuda_runtime_api.h>
#include <cutil_inline.h>
#include <multithreading.h>

//#include <time.h> // for tsrtuct
#include <sys/timeb.h>
#include <iostream>
#include <stdlib.h>
using namespace std;
using std::cin;
using std::cout;

#define TWO_PI 6.283185307179586476925286766558
#define IDX2C( i, j, ld) ((i)+(( j )*( ld )))

extern int iDebugLvl, iWarnings, iErrors, iTrace;
extern long bCUDAavailable;

//////////////// class cDrover begins ////////////////

void cDrover::ShowMe()
{
	//ShowMeSes(* rSes, false);
	printf("Am Volga boatman.\n");
}


long cDrover::SetContext( rohanContext& rC)
{/// enables pointer access to master context struct
	rSes = &rC;
	return 0;
}


long cDrover::SetDroverBargeAndTeam( class cDrover * cdDrover, class cBarge * cbBarge, class cDeviceTeam * cdtTeam)
{mIDfunc /// sets pointers to hitch barge to team and mount driver on barge
	Barge = cbBarge;
	Team = cdtTeam;
	Barge->SetDrover(cdDrover);
	Barge->SetTeam(Team);
	Team->SetDrover(cdDrover);
	Team->SetBarge(Barge);
	return 0;
}


long cDrover::DoAnteLoop(int argc, char * argv[], class cDrover * cdDrover, class cBarge * cbBarge, class cDeviceTeam * cdtTeam)
{mIDfunc /// This function prepares all parameters, contexts, and data structures necesary for learning and evaluation.
	int iReturn=0;

	// initiate relationship
	SetDroverBargeAndTeam( cdDrover, cbBarge, cdtTeam);
	
	strcpy(rSes->sCLargsOpt, "blank");
	strcpy(rSes->sConfigFileOpt,"blank");
	strcpy(rSes->sConsoleOpt,"blank");
	strcpy(rSes->sLearnSetSpecOpt,"blank");
		
	if (argc) {
		rSes->bConsoleUsed=false;
		rSes->bCLargsUsed=true;
		//strcpy(rSes->sCLargsOpt, argv[0]); // point to first argument
		// call function to parse CLI args here
	}
	else {
		rSes->bConsoleUsed=true;
		rSes->bCLargsUsed=false;
	} /// potentially abusable 
	printf("Rohan v%s Neural Network Application\n", VERSION);
	//print_NVCC_min_spec();
	iTrace=0;
	if (CUDAverify(*rSes)){
		cout << "CUDA present" << endl;
		iReturn=ObtainGlobalSettings(*rSes);
		AskSampleSetName(*rSes);
		if (Barge->ObtainSampleSet(*rSes)){
			//ShowMeEvals(*rSes,1);
			iReturn=Barge->DoPrepareNetwork(*rSes);	
			cdtTeam->LetHitch(*rSes);
			//ShowMeEvals(*rSes,1);
			printf("Team.RMSE = %f\n", cdtTeam->GetRmseNN(*rSes, 0));
			//ShowMeEvals(*rSes,1);
			cdtTeam->TransferOutputs(*rSes,'H');
			//ShowMeEvals(*rSes,1);
			iReturn=ShowDiagnostics(*rSes);
			Barge->ShowDiagnostics();
			cdtTeam->LetUnHitch(*rSes);
		}
		else {
			cout << "Failed to load samples" << endl;
		}
	}
	else {
		fprintf(stderr, "Unrecoverable Error: No CUDA hardware or no CUDA functions present.\n", ++rSes->iErrors);
		iReturn=0;
	}
	//ShowMeEvals(*rSes,1);
	return iReturn;
}


int CUDAverify(struct rohanContext& rSes)
{mIDfunc/// Checks for prsence of CUDA-enabled hardware
	FILE *fShow=rSes.debugHandle;
	int deviceCount; double compCap=1.0, check;
	cudaGetDeviceCount(&deviceCount); 
	for (int device = 0; device < deviceCount; ++device) { 
		rSes.deviceProp; 
		cudaGetDeviceProperties(&rSes.deviceProp, device); 
		// following section borrowed from CUDA SDK, (C) Nvidia
		fprintf(fShow,"Device %d has compute capability %d.%d.\n", device, rSes.deviceProp.major, rSes.deviceProp.minor);
			fprintf(fShow,"  Total amount of global memory:                 %.0f MBytes (%llu bytes)\n", 
				(float)rSes.deviceProp.totalGlobalMem/1048576.0f, (unsigned long long) rSes.deviceProp.totalGlobalMem);
			fprintf(fShow,"  (%2d) Multiprocessors x (%2d) CUDA Cores/MP:     %d CUDA Cores\n", 
				rSes.deviceProp.multiProcessorCount, ConvertSMVer2Cores(rSes.deviceProp.major, rSes.deviceProp.minor),
				ConvertSMVer2Cores(rSes.deviceProp.major, rSes.deviceProp.minor) * rSes.deviceProp.multiProcessorCount);
			//int L2CacheSize;
			//getCudaAttribute<int>( &L2CacheSize, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, device );
			//if (L2CacheSize) {fprintf(fShow,"  L2 Cache Size:                                 %d bytes\n", L2CacheSize);}
			fprintf(fShow,"  Max Texture Dimension Size (x,y,z)             1D=(%d), 2D=(%d,%d), 3D=(%d,%d,%d)\n",
				rSes.deviceProp.maxTexture1D, rSes.deviceProp.maxTexture2D[0], rSes.deviceProp.maxTexture2D[1],
                rSes.deviceProp.maxTexture3D[0], rSes.deviceProp.maxTexture3D[1], rSes.deviceProp.maxTexture3D[2]);
			fprintf(fShow,"  Max Layered Texture Size (dim) x layers        1D=(%d) x %d, 2D=(%d,%d) x %d\n",
				rSes.deviceProp.maxTexture1DLayered[0], rSes.deviceProp.maxTexture1DLayered[1],
                rSes.deviceProp.maxTexture2DLayered[0], rSes.deviceProp.maxTexture2DLayered[1], rSes.deviceProp.maxTexture2DLayered[2]);
			fprintf(fShow,"  Total amount of constant memory:               %u bytes\n", rSes.deviceProp.totalConstMem); 
			fprintf(fShow,"  Total amount of shared memory per block:       %u bytes\n", rSes.deviceProp.sharedMemPerBlock);
			fprintf(fShow,"  Total number of registers available per block: %d\n", rSes.deviceProp.regsPerBlock);
			fprintf(fShow,"  Warp size:                                     %d\n", rSes.deviceProp.warpSize);
			fprintf(fShow,"  Maximum number of threads per block:           %d\n", rSes.deviceProp.maxThreadsPerBlock);
			fprintf(fShow,"  Maximum sizes of each dimension of a block:    %d x %d x %d\n",
				rSes.deviceProp.maxThreadsDim[0],
				rSes.deviceProp.maxThreadsDim[1],
				rSes.deviceProp.maxThreadsDim[2]);
			fprintf(fShow,"  Maximum sizes of each dimension of a grid:     %d x %d x %d\n",
				rSes.deviceProp.maxGridSize[0],
				rSes.deviceProp.maxGridSize[1],
				rSes.deviceProp.maxGridSize[2]);
			// end borrowed section
		check=rSes.deviceProp.major + rSes.deviceProp.minor * 0.1;
		if (check>compCap)
			compCap=check;
	}
	if(compCap<2.0) { 
		rSes.bCUDAavailable=false;
		++rSes.iWarnings;
		printf("%3.1f capable CUDA device(s) located\n", compCap); 
		}
	else {
		rSes.bCUDAavailable=true;
		printf("%3.1f capable CUDA device(s) located\n", compCap); 
	}

	if(rSes.bCUDAavailable)
		return 1; // available
	else
		return 0; // not available
}

long cDrover::ObtainGlobalSettings(struct rohanContext& rSes)
{mIDfunc /// sets initial and default value for globals and settings
	int iReturn=0;
	
	//	globals
	iTrace=0; if (iTrace) cout << "Tracing is ON.\n" ;
	iDebugLvl=0; if (iDebugLvl) cout << "Debug level is " << iDebugLvl << "\n";
	// session accrual
	rSes.iWarnings=0; rSes.iErrors=0; cout << "Session warning and session error counts reset.\n";
	rSes.lSampleQtyReq=0;
	// session modes
	rSes.bContActivation=true; cout << "Activation default is CONTINUOUS.\n";
	rSes.bRInJMode=false; if (rSes.bRInJMode) cout << "Reversed Input Order is ON.\n"; // this is working backward for some reason 2/08/11
	rSes.bRMSEon=true; cout << "RMSE stop condition is ON. XX\n"; //
	rSes.iEpochLength=1000; cout << "Epoch length is 1000 iterations.\n";
	strcpy(rSes.sSesName,"DefaultSession");
	rSes.rLearn->bContInputs=true; cout << "Continuous Inputs true by DEFAULT.\n";
	rSes.rLearn->iContOutputs=true; cout << "Continuous Outputs true by DEFAULT.\n";
	
	return iReturn;
}


long cDrover::AskSampleSetName(struct rohanContext& rSes)
{mIDfunc /// chooses the learning set to be worked with Ante-Loop
	int iReturn=0; 
	//rSes.rLearn->bContInputs=false;
	//rSes.rLearn->iContOutputs=(int)false;
	cout << "Samples treated as discrete or continuous by fractionality. XX" << endl;

	printf("Enter 0 for 10K-set, weights\n\t 1 for 3-set, weights\n\t 2 for 150-set, no wgts\n\t 3 for 3-set, no wgts\n\t 4 for 2-1 rand weights");
	printf("\n\t 5 for 416 samples x 200 inputs\nEnter 10+ for basic diag\n\t30+ for more diag\n\t70+ for full diag\n");
	std::cin >> iDebugLvl;
	//cout << "Loading trivial3 test learning set" << endl;
	//iDebugLvl=4;
	switch ( iDebugLvl % 10) {
		case 0:
		  rSes.rLearn->sLearnSet="AirplanePsDN1W3S10k.txt";
		  break;
		case 1:
		  rSes.rLearn->sLearnSet="trivial.txt";
		  break;
		case 2:
		  rSes.rLearn->sLearnSet="iris.txt";
		  break;
		case 3:
		  rSes.rLearn->sLearnSet="trivial2.txt";
		  break;
		case 4:
		  rSes.rLearn->sLearnSet="trivial3.txt";	
		  break;
		case 5:
		  rSes.rLearn->sLearnSet="PC-63-32-200-LearnSet.txt";
		  break;
		default:
		  rSes.rLearn->sLearnSet="iris.txt";
		  break;
	}
	rSes.iDebugLvl=iDebugLvl/=10; // drop final digit
	if (iDebugLvl) fprintf(stderr, "Debug level is %d.\n", iDebugLvl);
	return iReturn;
}


long cDrover::ShowDiagnostics(struct rohanContext& rSes)
{mIDfunc /// show some statistics, dump weights, and display warning and error counts
	double devdRMSE=0.0;
	int iReturn=1;
	long lSamplesEvald;
	
	printf("cDrover: ");
	lSamplesEvald = cuEvalNNLearnSet(rSes);
		if (lSamplesEvald) printf("%d samples evaluated, ", lSamplesEvald);
		else {printf("No samples evaluated by cuEvalNNLearnSet\n");
			++rSes.iErrors;
			printf("Waiting on keystroke...\n"); _getch(); return iReturn;
		}
	////lSamplesEvald=devEvalNNLearnSet(rSes);
	int iDifferent = OutputValidate(rSes);
	printf("%d differences found on verify.\n", iDifferent);
	rSes.dRMSE = RmseNN(rSes, 0);
	////devdRMSE=knlRMSE(rSes, 0);
	printf("RMSE host/dev %e/%e\n", rSes.dRMSE, devdRMSE);
	// some illustrative default values
	rSes.dTargRMSE=floor(rSes.dRMSE-1.0)+1.0;
	rSes.dMAX=(double)abs(rSes.dRMSE-1.0);
	printf("RMSE target is %e.\n", rSes.dTargRMSE);
	printf("MAX threshold is %e.\n", rSes.dMAX);
	int iTrainable = Team->LetTrainNNThresh(rSes, false, 'd');
	printf("%d trainable sample outputs found.\n", iTrainable);

	Barge->LetWriteWeights(rSes);// record weights for posterity
	
	if (rSes.iWarnings) fprintf(stderr, "%d warnings.\n", rSes.iWarnings);
	if (rSes.iErrors) fprintf(stderr, "%d operational errors.\n", rSes.iErrors);

	return iReturn;
}


long cDrover::DoMainLoop(struct rohanContext& rSes)
{mIDfunc /// Trains a weight set to more closely reproduce the sampled outputs from the sampled inputs, and other options.
	int iReturn=0, iSelect=1;
	cout << "Main duty loop begin." << endl;
	
	while(iSelect){
		iSelect=DisplayMenu(0, rSes);
		if (iSelect==1) iReturn=BeginSession(rSes); // new or resume session
		if (iSelect==2) iReturn=GetNNTop(rSes);
		//if (iSelect==3) iReturn=ReGetSampleSet(rSes); XX
		if (iSelect==4) iReturn=GetWeightSet(rSes);
		if (iSelect==5) iReturn=this->LetInteractiveEvaluation(rSes);
		if (iSelect==6) iReturn=this->LetInteractiveLearning(rSes);
		if (iSelect==7) iReturn=cuPreSaveNNWeights(rSes);
		if (iSelect==8) iReturn=dualRandomizeWeights(rSes);
		//if (iSelect==8) iReturn=TestPatLS(rSes, false)+ShowMeLS(rSes, false)+ShowMeST(rSes, false)+TestPatWS(rSes, false)+ShowMeWS(rSes, false)+ShowMeSes(rSes, false);
		//if (iSelect==9) iReturn=devResetAllDeltasAndOutputs(rSes)+ShowMeErr(rSes, false)+ShowMeLS(rSes, true)+ShowMeWS(rSes, false)+ShowMeSes(rSes, false);
		//if (iSelect==9) iReturn=devResetAllDeltasAndOutputs(rSes)+ShowMeErr(rSes, false)+ShowMeLS(rSes, false)+ShowMeWS(rSes, false)+ShowMeSes(rSes, false);
		if (iSelect==9) {
			//ShowMeLS(rSes,1);
			ShowMeSes(rSes,1);
			ShowMeLay(rSes,1);
			ShowMeEvals(rSes,1);
		}
		SilentDiagnostics(rSes);
	}
	return 0;
}


int DisplayMenu(int iMenuNum, struct rohanContext& rSes)
{mIDfunc
	char a='.';
	if(iMenuNum==0){
		printf("\n1 - Label session \"%s\"", rSes.sSesName);
		printf("\n2 - Network topology setup");
		printf("\n3 - Sample set load");
		printf("\n4 - Weight set load");
		printf("\n5 - Evaluation Feed Forward");
		printf("\n6 / Learning");
		printf("\n7 - Save weights");
		printf("\n8 - Randomize weights");
		printf("\n9 - showme");
		printf("\n0 - Quit");
		printf("\n %s %d samples MAX %e, %d trainable", rSes.rLearn->sLearnSet, rSes.rLearn->lSampleQty, rSes.dMAX, TrainNNThresh(rSes, false));
		printf("\nDRMSE %e YRMSE %e ", rSes.dTargRMSE, rSes.dRMSE);
		for(int i=0;i<rSes.rNet->iLayerQty;++i)
			printf("L%d %d; ", i, rSes.rNet->rLayer[i].iNeuronQty);
		//if (rLearn.iContOutputs) printf("Output Cont ");
		//else printf("Output Disc ");
		printf("%d sectors ", rSes.rNet->iSectorQty);
		//if (rSes.bContActivation) printf("Activ Cont ");
		//else printf("Activ Disc ");
		if (rSes.bRInJMode) printf("ReverseInput "); 
	}
	printf("\n");
	// http://www.cplusplus.com/doc/ascii/
	while(a<'0'||a>'9')
		a=_getch();
	return ((int)a)-48;
}


int BeginSession(struct rohanContext& rSes)
{mIDfunc /// accepts keyboard input to define the name of the session, which will be used to name certain output files.
	cout << "\nEnter a session name: ";
	cin >> rSes.sSesName; 

	return 1;
}


int GetNNTop(struct rohanContext& rSes)
{mIDfunc /// sets up network poperties and data structures for use
	char sNeuronsPerLayer[254];
	int iSectorQty, iInputQty;

	cout << "Enter # of sectors (0 to return): ";
	cin >> iSectorQty;
	if(iSectorQty){
		cout << "Enter # of inputs (0 to return): ";
		cin >> iInputQty; // last chance to quit
	}
	if(iSectorQty && iInputQty) {
		cuFreeNNTop(rSes); // release old network structures
		rSes.rNet->iSectorQty=iSectorQty; // update sector qty
		rSes.rNet->kdiv2=iSectorQty/2; // update sector qty
		rSes.rLearn->iInputQty=iInputQty; // upsdate input qty
		cout << "Enter numbers of neurons per layer separated by commas, \ne.g. 63,18,1 : ";
		cin >> sNeuronsPerLayer;
		cuMakeLayers(iInputQty, sNeuronsPerLayer, rSes); // make new layers
		rSes.rNet->dK_DIV_TWO_PI = rSes.rNet->iSectorQty / TWO_PI; // Prevents redundant conversion operations
		cuMakeNNStructures(rSes); // allocates memory and populates network structural arrays
		cuRandomizeWeights(rSes); // populate newtork with random weight values
		printf("Random weights loaded.\n");
		printf("%d-valued logic sector table made.\n", cuSectorTableMake(rSes));
		printf("\n");
		return rSes.rNet->iLayerQty;
	}
	else
		return 999;
}


long cuFreeNNTop(struct rohanContext &rSes)
{mIDfunc/// frees data structures related to network topology
	cublasStatus csStatus;
	
	free( rSes.rNet->cdcSectorBdry );
	// layer components
	free( rSes.rNet->rLayer[0].ZOutputs ); // Layer Zero has no need of weights!
	csStatus = cublasFree( rSes.rNet->rLayer[0].ZOutputs ); // de-allocate a GPU-space pointer to a vector of complex neuron outputs for each layer
	mCuMsg(csStatus,"cublasFree()")
	
	for (int i=1; i < rSes.rNet->iLayerQty; ++i){ 
		struct rohanLayer& lay=rSes.rNet->rLayer[i];
		free( lay.Weights ); // de-allocate a pointer to an array of arrays of weights
		free( lay.ZOutputs ); // de-allocate a pointer to an array of arrays of weights
		free( lay.Deltas ); // free the backprop areas
	}
	free( rSes.rNet->rLayer ); // free empty layers
	printf("Network structures freed.\n");
	return 0;
}

int cuMakeNNStructures(struct rohanContext &rSes)
{mIDfunc
/*! Initializes a neural network structure of the given number of layers and
 *  layer populations, allocates memory, and populates the set of weight values randomly.
 *
 * iLayerQty = 3 means Layer 1 and Layer 2 are "full" neurons, with output-only neurons on layer 0.
 * 0th neuron on each layer is a stub with no inputs and output is alawys 1+0i, to accomodate internal weights of next layer.
 * This allows values to be efficiently calculated by referring to all layers and neurons identically.
 * 
 * iNeuronQty[1] is # of neurons in Layer 1
 * iNeuronQty[2] is # of neurons in Layer 2
 * iNeuronQty[0] is # of inputs in Layer 0 */
	long lReturn=0;
const cuDoubleComplex cdcZero = { 0, 0 }, cdcInit = { -999.0, 999.0 };
	//cdcInit.x=-999.0; cdcInit.y=999.0;
	for (int i=0; i < rSes.rNet->iLayerQty; ++i){  //Layer Zero has no need of weights! 8/13/2010
		struct rohanLayer& lay = rSes.rNet->rLayer[i];
		struct rohanNetwork * rnSrc = rSes.rNet;
		long DQTY, NQTY, WQTY, DSIZE, NSIZE, WSIZE, L=i;
		//setup dimension values
		DQTY = rnSrc->rLayer[L].iDendriteQty + 1 ; // dendrites = incoming signals
		DSIZE = DQTY * sizeof(cuDoubleComplex) ;
		NQTY = rnSrc->rLayer[L].iNeuronQty + 1 ; // neurons = outgoing signals
		NSIZE = NQTY * sizeof(cuDoubleComplex) ;
		WQTY = DQTY * NQTY ; // weights = weights
		WSIZE = WQTY * sizeof(cuDoubleComplex) ;
		
		//allocate memory
		lay.Weights = (cuDoubleComplex*)malloc ( WSIZE ); // 2D array of complex weights
			mCheckMallocWorked(lay.Weights)
		lay.XInputs = (cuDoubleComplex*)malloc( DSIZE ); //allocate a pointer to an array of outputs
			mCheckMallocWorked(lay.XInputs)
		lay.ZOutputs = (cuDoubleComplex*)malloc( NSIZE ); //allocate a pointer to an array of outputs
			mCheckMallocWorked(lay.ZOutputs)
		lay.Deltas = (cuDoubleComplex*)malloc( WSIZE ); //allocate a pointer to an parallel array of learned corrections
			mCheckMallocWorked(lay.Deltas)
		lReturn+=lay.iNeuronQty*lay.iDendriteQty;
   		lReturn+=lay.iNeuronQty;
	
		//init values
		for (int k=0; k <= lay.iDendriteQty; ++k){
			for (int j=0; j <= lay.iNeuronQty; ++j){ 
				lay.Weights[IDX2C(j, k, lay.iNeuronQty+1)].x=(double)rand()/65535; // necessary to promote one operand to double to get a double result
				lay.Weights[IDX2C(j, k, lay.iNeuronQty+1)].y=(double)rand()/65535;
				lay.Deltas[IDX2C(j, k, lay.iNeuronQty+1)]=cdcInit;
			}
			// reset neuron 0 weights to null
			lay.Weights[IDX2C(0, k, lay.iNeuronQty+1)] = cdcZero;
			//lay.Weights[IDX2C(0, k, lay.iNeuronQty+1)].y=0;
			lay.XInputs[k]=cdcInit;
		}
		lay.Weights[IDX2C(0, 0, lay.iNeuronQty+1)].x=1.0; // neuron 0 interior weight should always be equal to 1
		for (int j=0; j <= lay.iNeuronQty; ++j){
			lay.ZOutputs[j]=cdcInit;
		}
	}
	return lReturn; //return how many weights and outputs allocated
}


int GetWeightSet(struct rohanContext& rSes)
{mIDfunc /// chooses and loads the weight set to be worked with
	int iReturn=0; 
	char sWeightSet[254];
	FILE *fileInput;
	
	cout << "Enter name of binary weight set: ";
	std::cin >> sWeightSet;
	// File handle for input
	
	iReturn=BinaryFileHandleRead(sWeightSet, &fileInput);
	if (iReturn==0) // unable to open file
		++rSes.iErrors;
	else{ // file opened normally
		// file opening and reading are separated to allow for streams to be added later
		iReturn=cuNNLoadWeights(rSes, fileInput);
		if (iReturn) printf("%d weights read.\n", 
			iReturn);
		else {
			printf("No Weights Read\n");
			iReturn=0;
		}
	}
	printf("\n");
	return iReturn;
}


long cDrover::LetInteractiveEvaluation(struct rohanContext& rSes)
{mIDfunc /// allows user to ask for different number of samples to be evaluated
	int iReturn=0;
	printf("Enter qty of samples to evaluate, or 0 to end\n");
	std::cin >> rSes.lSampleQtyReq;
	++iReturn;
	while(rSes.lSampleQtyReq){
		// serial values are computed and then displayed
		//cuEvalNNLearnSet(rSes);
		Team->LetEvalSet(rSes,0,'c');
		rSes.dRMSE = RmseNN(rSes, rSes.lSampleQtyReq);
		printf("%s: first %d samples requested\nRMSE= %f", rSes.rNet->sWeightSet, rSes.lSampleQtyReq, rSes.dRMSE);
		// parallel method takes over in mid-sentence to visualize speed difference
		////devEvalNNLearnSet(rSes);
		double devdRMSE=knlRMSEopt(rSes, rSes.lSampleQtyReq, 0, 'R'); // XX
		printf("/%f\n", devdRMSE);
		printf("Enter qty of samples to evaluate, or 0 to end\n");
		std::cin >> rSes.lSampleQtyReq;
		++iReturn;
	}
	return iReturn;
}


long cDrover::LetInteractiveLearning(struct rohanContext& rSes)
{mIDfunc /// allows user to select learning threshold
	int iReturn=0;
	//rSes.dRMSE = RmseNN(rSes, 0);
	rSes.dRMSE = knlRMSEopt(rSes,0,0,'R');
	//double dTargRMSE;
	printf(" Achieved RMSE = % #3.3g\n", rSes.dRMSE);
	printf("Enter desired RMSE for learning, or 0 to end\n");
	std::cin >> rSes.dTargRMSE;
	if(rSes.dTargRMSE){
		printf(" MAX = % #3.3g\n", rSes.dRMSE);
		printf("Enter MAX allowable error per sample, or 0 to end\n");
		std::cin >> rSes.dMAX;
		if(rSes.dMAX){
			printf(" Epoch length = %d\n", rSes.iEpochLength);
			printf("Enter iterations per epoch, or 0 to end\n");
			std::cin >> rSes.iEpochLength;
			if(rSes.iEpochLength){
				printf(" Sample qty = %d\n", rSes.lSampleQtyReq);
				printf("Enter samples requested, or 0 to end\n");
				std::cin >> rSes.lSampleQtyReq;
				if(rSes.lSampleQtyReq){
					++iReturn;
					long count = 0; rSes.lSamplesTrainable=1; //set trainable to 1 to allow loop to proceed at least once
					while(rSes.dTargRMSE<rSes.dRMSE && rSes.lSamplesTrainable && count < rSes.iEpochLength){ // target not met, trainable samples left
						rSes.lSamplesTrainable=TrainNNThresh(rSes , true);
						cuEvalNNLearnSet(rSes);
						////devEvalNNLearnSet(rSes);
						//rSes.dRMSE = RmseNN(rSes, 0);
						rSes.dRMSE = knlRMSEopt(rSes, rSes.lSampleQtyReq, 0,'R' );
						//printf(" RMSE = %f/%f, trainables %d, iteration %d\n", RmseNN(rSes, 0), rSes.dRMSE, rSes.lSamplesTrainable,++count);
						//++count;
						printf(" RMSE = % #3.5g, trainable samples %d, iteration %d\n", rSes.dRMSE, rSes.lSamplesTrainable, ++count);
						++iReturn;
					}
				}
			}
			if(rSes.lSamplesTrainable)
				if(rSes.dTargRMSE>=rSes.dRMSE)
					printf(" Achieved RMSE target %f.\n", rSes.dRMSE);
				else printf(" Completed epoch of %d iterations.\n", rSes.iEpochLength);
			else printf(" No trainable samples with MAX % #3.3g\n", rSes.dMAX);
		}
	}
	return iReturn;
}


long cDrover::DoPostLoop(struct rohanContext& rSes) 
{mIDfunc /// Final operations including freeing of dynamically allocated memory are called from here. 
	int iReturn=0, iSelect=0;

	printf("Program terminated after %d warning(s), %d operational error(s).\n", rSes.iWarnings, rSes.iErrors);
	DoEndItAll(rSes);
	printf("Waiting on keystroke...\n");
	_getch();

	return 0;
}


int SilentDiagnostics(struct rohanContext& rSes)
{mIDfunc /// show some statistics, dump weights, and display warning and error counts
	int iReturn=0;
	
	long lSamplesEvald = cuEvalNNLearnSet(rSes);
	int iDifferent = OutputValidate(rSes);
	//printf("%d differences found on verify.\n", iDifferent);
	rSes.dRMSE = RmseNN(rSes, 0);
	//printf("RMSE %f\n", rSes.dRMSE);
	// some illustrative default values
	rSes.dTargRMSE=floor(rSes.dRMSE-1.0)+1.0;
	rSes.dMAX=(double)abs(rSes.dRMSE-1.0);
	//printf("RMSE target is %f.\n", rSes.dTargRMSE);
	//printf("MAX threshold is %f.\n", rSes.dMAX);
	int iTrainable = TrainNNThresh(rSes, false);
	//printf("%d trainable sample outputs found.\n", iTrainable);

	// dump weights for verification
	FILE *fileOutput; // File handle for input
	iReturn=AsciiFileHandleWrite("weightdump.txt", &fileOutput);
	AsciiWeightDump(rSes, fileOutput); //XX link error
	
	if (rSes.iWarnings) fprintf(stderr, "%d warnings.\n", rSes.iWarnings);
	if (rSes.iErrors) fprintf(stderr, "%d operational errors.\n", rSes.iErrors);

	return iReturn;
}


long cDrover::DoEndItAll(struct rohanContext& rSes)
{mIDfunc /// prepares for graceful ending of program
	int iReturn=0;

	iReturn=Barge->DoCuFree(rSes);

	return iReturn;
}
